# Compounding Intelligence — Mathematical Synopsis

*Version 24 · September 17, 2026*

This synopsis is the authoritative source of mathematical truth for the CI platform.
Every equation, parameter value, constraint, and invariant in the tech paper, arxiv paper,
innovation note, claims registry, and component design documents traces back to this document.
When this document changes, downstream documents must be checked for consistency.

The objects, operations, and invariants this document makes claims about are defined canonically
in the **CI Math Engine Architecture (v6, Sep 2026)** (State / Operations / Invariants / Certification).
This document is the **claim ledger** over those operations; it does not redefine them.

---

## Certification — two orthogonal axes (canonical: CI Math Engine Architecture)

Every claim here carries **two tiers on
two orthogonal axes** — they answer different questions and are composed, not competing:

- **Maturity tier (this ledger's Tier 1–5):** *how proven is the claim?* — analytic-only, simulation-
  confirmed, production-faithful, pilot-validated. Tier 1 is the top (pilot-validated).
- **Signal tier (engine T-\*):** *what generated the correctness signal?* — **T-arch** (by construction),
  **T-geom** (geometry-derived oracle), **T-real** (real-component / exported production geometry),
  **T-sim** (simulated streams/adversaries/competitors), **T-pilot** (verified human outcomes, live).

**The composition rule (how the two axes lock together):**
> A claim reaches **maturity Tier 1 if and only if its signal tier is T-pilot** — verified human outcomes
> from a live deployment. Analytic + T-geom/T-real/T-sim evidence can carry a claim to **Tier 2** (QUALIFIED);
> the step to Tier 1 is exactly the arrival of T-pilot signal (this is what EXP-G1 provides for γ). So the
> two axes are not independent labels — the signal axis **gates** the maturity axis at the top rung.

**The correctness-signal bright line (engine rule, absorbed here):** the ledger **rejects K3** — an
LLM-judged correctness signal (an LLM generating both inputs and decisions) — as evidence for **any** claim
at **any** tier. Admissible signals are K1/K2 (oracle-separated → T-geom) and real/verified data (→ T-real /
T-pilot). The measured cost of the K3 violation is logged as CLAIM-K14 (below).

**CLAIM-K14 — LLM-judged correctness is blind on investigation-dependent decisions.**
On 240 real LLM (Claude Sonnet, T=0) judgments against a geometry-derived ground-truth anchor across five
copilots, an LLM judge's agreement with ground truth collapses from ~0.86 on surface-resolvable decisions
(SOC) to 0.08–0.12 on investigation-dependent decisions (S2P/Trading/DataOps); where measurable, the judge's
correctness tracks its own confidence (r = 0.60 SOC, 0.45 Purchasing, n=50). The geometry-derived check
(K3-axis: T-geom) agrees with the same anchor 0.76–1.00 on four of five copilots.
- **Signal tier:** T-geom (geometry-derived anchor) + T-sim (adversarial surface-wrong scenarios).
- **Maturity tier:** Tier 2 — measured on real LLM judgments vs a geometry-derived anchor; not pilot.
- **Role:** this is the *measured cost of the K3 bright-line violation* (§Certification) — it certifies the
  engine's certification rule, it is not a capability claim about the product.
- **Scope:** Astra scenarios designed surface-wrong (isolates "when the answer is not on the surface, the
  judge is blind"), not a natural-prevalence accuracy. n=49 DataOps of 240 total.

**K14 Part 2 — Compounding under noise.** When K14-measured noise rates are injected into the compounding
harness, learning degrades:

| Copilot | K2 agreement | Noise rate | Clean Δ | Noisy Δ | Clean−Noisy |
|---------|-------------|-----------|---------|---------|-------------|
| SOC | 0.860 | 14% | +19.0pp | +19.3pp | −0.3pp |
| Purchasing | 0.400 | 60% | +17.7pp | +17.7pp | +0.0pp |
| DataOps | 0.120 | 88% | +10.3pp | +5.0pp | +5.3pp |
| Trading | 0.100 | 90% | +12.0pp | +2.0pp | +10.0pp |
| S2P | 0.080 | 92% | +5.7pp | −2.0pp | +7.7pp |

Compounding degrades 5–10pp at 88–92% noise and reverses at 92% (S2P). It is unaffected below 60%.
The crossover is between 60% and 88% noise. Mean clean−noisy is +4.5pp; 3/5 copilots exceed 3pp.
- **Signal tier:** T-geom (geometry-derived anchor) + T-sim (noise injection).
- **Maturity tier:** Tier 2.

---

- v24 (Sep 17, 2026) — Three-layer safety gate (A1-R1/R2). G-RATE added as the third
  conservation layer (`W_short=20`, `m_rate=0.85×`, 86.7% detection, 0.87% false-pause).
  `V_clear` corrected to ≈3 (was V≈8). K14 Part 2 compounding-under-noise data added.
  Trading tensor verified at (5,4,10)=200 (SAFE-2). Purchasing ρ=3:1 added. Engine
  reference updated to v6. A1 experiment entry added. ~50 lines added/changed, no content removed.

  Two-axis certification (signal tier T-arch/T-geom/T-real/T-sim/T-pilot orthogonal to
  maturity Tier 1–5). CLAIM-K14 (LLM validation blindness), CLAIM-MOAT-B2 (firm-specific
  non-transferable advantage), CLAIM-CTRL-2C (RL enrichment controller), INVARIANT A0
  (acquisition not depth), CLAIM-4READOUT (confidence from trajectory). Gate GAMMA signal-
  tier tagged. ~120 lines added, no content removed.
- v18 (June 1, 2026) — Canonical decisions D1–D4. α canonicalized to cumulative category
  coverage (override-rate definition retired; override_rate now a distinct symbol feeding
  a v18 complacency ADVISORY, not the conservation gate). Re-convergence quantity renamed
  α_cat → α_disrupt (C-MS-8) so the two α meanings no longer collide in this document.
  Compounding vocabulary split into information-gain (b=2.11, sim-only) and operational
  (c=1.14, bounded transient). θ_min = 23.53/(α×V) reframed as empirically-calibrated
  cold-start interlock; prior "derivations" retired. Signal-confidence inversion sourcing
  clarified. (Internal label reconciled from v14 → v18 to match filename chain.)
- v14 (April 19, 2026) — UNI-DK-01 v5.3 incorporation. DK characterization surface, calibration
  finding, q operational definition tightened, KernelSelector architecture settled.
- v13 (April 8, 2026) — Re-Convergence Theorem (γ > 1 proven for ε_firm > 0.125).
- v12 (April 1, 2026) — θ_min=23.53/(α×V) formula. Per-analyst η_i. D6 closed.
  FINDING-OVR-01. Self-calibrating gates.
- v11 (March 21, 2026) — A=4 confirmed, ReferralRules R1-R7 shipped, ~104 experiments.
- v10 (March 21, 2026) — DiagonalKernel validated, asymmetric η (P0 fix), tensor A=4.
- v9.1 (March 17, 2026) — Three-judge validated bridges, convergence analysis, conservation law.
- v9 (March 15, 2026) — A=5/A=4 tensor, Eq 4b correction, frozen scorer baseline.

---

## 1. The Architecture in One Paragraph

The system is a compounding-intelligence platform that reshapes decision geometry from verified outcomes. Layer 1 (ProfileScorer) scores analyst decisions against a 6×4×6 = 144-value centroid tensor using L2 distance (nearest-prototype scoring). The kernel choice alone is worth 36.89pp over dot product on bounded features (EXP-C1). A per-factor weighting scheme (DiagonalKernel, W=diag(1/σ²)) was investigated and found to be preprocessing-dependent on real data — positive on some dataset/convention cells (Bank Marketing min-max: +10.0pp), negative on others — making it a deployment-specific option, not a safe default. L2 is retained as the production kernel. The per-factor noise fingerprint (σ, from outcome-conditioned variance) survives as a diagnostic: it surfaces signal-confidence inversion and judgment biases, but does not weight the scoring kernel. Centroid learning uses an asymmetric learning rule (η_confirm=0.05 on agreements, η_override=0.01 on disagreements), bounded by the conservation law α·q·V ≥ θ_min. The learning curve is logistic (R²≈0.88, d²q/dt² > 0 for t < ~330 decisions, measured).

Layer 2 (AgentEvolver) evolves HOW the system operates (prompts, gates, scoring configs, routing rules) via a procedural-memory sidecar with five domain-specific reward functions, conservation-bounded exploration (ConservationBoundedThompson), shadow-test → promotion-gate → rollback. The G1 guarantee: action selection is never reward-maximizing — the judgment core (centroid distance + softmax) is the authoritative decision path; RL/evolution operates after verified outcomes and never replaces the centroid-selected action. Under adversarial poisoning (20% harmful inputs), AgentEvolver's drift-triggered rollback + η damping reduced non-recovery from 57% to 14% (EXP-AE-DECISION, validated). Scorer-integrated RL (routing reward signals into the scorer's η) was confirmed across four experiments and six strategies — uniform η=0.05 is the robust default, validating the sidecar architecture (EXP-RL-SCORER). A safety architecture (S1–S10) prevents synthesis contamination, centroid corruption from low-quality overrides, and compounding degradation during regime shift. The conservation law invariant α(t)·q(t)·V(t) ≥ θ_min — where **α = cumulative category coverage (c_d/C)**, q = **rolling verified accuracy over the last 400 decisions**, and V = verified decisions/day — is the runtime guarantee that experimentation cannot cannibalize decision quality.

The centroid geometry (μ), noise fingerprint (per-factor σ), and conservation law (α·q·V ≥ θ_min) constitute what we term judgment memory — a fourth cognitive architecture type alongside the episodic, semantic, and procedural types defined by the CoALA framework (Sumers et al., 2023). Judgment memory stores not what happened or what is true, but how well decisions are made and where they are noise. The per-factor σ reveals signal-confidence inversion: the factor practitioners trust most (e.g., device_trust σ=0.28 in SOC) is systematically the noisiest predictor of correct outcomes. The σ fingerprint is diagnostic, not operational — it does not improve scoring or enrichment allocation when used as a weight or budget signal — EXP-RL-DIRECT-3 confirmed uniform enrichment as the robust default (+6.9pp), but it surfaces systematic judgment biases no other memory type can detect. SituationAnalyzer provides reasoning autonomy (graph-mediated semantic consolidation; enrichment value: +5.9pp, V-CGA-FROZEN); AgentEvolver provides decision autonomy (runtime evolution under conservation, validated). Together they form the production control plane (seven binding runtime gates, deployed across five copilots, 9,826 tests, zero failures).

This document provides the mathematical foundation for judgment memory and the compounding-intelligence architecture; the cga_arxiv paper (v15) provides the full formal evidence including the control plane and production characterization; the graph_native_reasoning_hero (v23) provides the practitioner-facing positioning. The JM redesign results note v6 provides the canonical JM apparatus measurements (c = 1.387, α_d = 2.150, β_d = 2.622, conservation per-threat-model, +21.96pp accuracy gain) — see §10.2 and Gate JM-APPARATUS in §13.

Key numerical constants (production, validated):

- **Tensor:** 6 categories × 4 actions × 6 factors = 144 values per domain
- **Trading tensor:** 5 categories × 4 actions × 10 factors = (5,4,10)=200 (SAFE-2 verified Sep 2026)
- **τ (temperature):** 0.1 (fixed; V3B validated, ECE=0.036)
- **η_confirm:** 0.05 (agreement learning rate, uniform across categories — RL-directed allocation: uniform confirmed as robust default, EXP-RL-SCORER)
- **η_override:** 0.01 (disagreement learning rate, P0 fix)
- **τ̂ (decision rate):** 0.001 (count decay)
- **α (conservation):** cumulative category coverage = c_d/C (NOT override rate — see D1, v18)
- **θ_min:** 23.53/(α×V) (deployment-specific conservation floor; empirically calibrated from N_half≈14)
- **Penalty ratios:** SOC 20:1, S2P 5:1, Trading 2:1, Purchasing 3:1, DataOps 10:1
- **Gate parameters:** `W_short=20`, `m_rate=0.85×`, `m_rel=0.7×` (fixed at approval)
- **ε_firm★:** ≈ 0.125 (re-convergence threshold; γ > 1 iff ε_firm > ε_firm★)
- **σ_max:** 0.034 (synthesis clipping; FX-1-PROXY-REAL derived)
- **κ* (IKS):** 0.20 (PROD-1 validated)
- **Kernel:** L2 (DiagonalKernel investigated — preprocessing-dependent on real data; deployment-specific option, not a safe default)
- **Logistic inflection:** ~327–361 decisions (learning curve d²q/dt² > 0 before, negative after; MEASURED)
- **AE adversarial protection:** non-recovery 57%→14% (−42.5pp, VALIDATED)
- **Total experiments:** ~194 (59 primary + 1890 factorial sub-cells, 7 phases)

**Gate parameter table (NEW v24):**

| Parameter | Value | Meaning | Lifecycle |
|---|---:|---|---|
| W_short | 20 | Rate-detector short window (G-RATE) | fixed at approval |
| m_rate | 0.85× | Rate-detector multiplier (G-RATE) | fixed at approval |
| m_rel | 0.7× | Relative-trigger multiplier (G-REL) | fixed at approval |

---

## 2. Five Layers

The platform is organized in five layers. Lower layers are the mathematical foundation;
higher layers leverage the compounding properties of lower layers.

| Layer | What it does | Validated by | Status |
|---|---|---|---|
| 1. ProfileScorer | Scores alerts via L2 distance to centroids | EXP-C1, EXP-B1, H-KERNEL (DK retracted) | ✅ L2 production |
| 2. Learning | Updates centroids from verified analyst decisions (uniform η=0.05) | SHIFT-2, V-HC-CONFIG, RL-SCORER (directed η closed) | ✅ uniform η |
| 3. Synthesis | Layers awareness (σ) on experience (μ) via coupled scoring | Design (pending EXP-S1-S8) | PROPOSAL |
| 4. Level 2 (AgentEvolver) | Conservative bandit evolves prompts/gates via promotion gate | Three-judge bridges | ✅ Design v6.0 |
| 5. Cross-graph attention | Multi-domain attention (cross-graph transfer) | cross_graph_attention_v3 design | Design v7+ |

Layers 1 and 2 are the foundation. Layer 3 is the next proposal (pending gate). Layer 4
is designed and awaiting EXP-L2 poisoning validation. Layer 5 is multi-year roadmap.

This synopsis focuses on Layers 1 and 2 (the validated foundation), with Level 2 formalized
in §5.

---

### §2.1 — Mathematical Abstractions

The GAE's mathematical architecture draws on ten abstractions from statistics, optimization, and information theory. Each serves a specific architectural role.

**1. Weighted-Distance Scoring** (Softmax over Kernel Distances). P(a|f,c) = softmax(−K(f, μ[c,a,:]) / τ). Nearest-centroid classification. Readable, auditable, grounded. §3 Eq. 4-final. Lineage: Cover & Hart 1967, Boltzmann/logistic regression.

**2. Constant Step-Size Stochastic Approximation.** μ ← μ + η·(f − μ) with fixed η. Tracks moving target (not converging to fixed point). Steady-state MSE = η·tr(Σ_f)/(2−η). §3 Eq. 4b-final. Lineage: Borkar 2008, Robbins-Monro 1951.

**3. James-Stein Shrinkage.** w̃ = λ × w_DK + (1−λ) × w_0 (where **λ = shrinkage intensity**; previously written as α in earlier versions — renamed to λ to resolve the symbol collision with conservation-law α = category coverage). Dominates either component for p ≥ 3. Mathematical guardrail in defense-in-depth. At λ=0.5: 0/21 below centroid. §3 Eq. SHRINKAGE, §3.4, §9.1. Lineage: Stein 1956, James & Stein 1961. Condition: p ≥ 3 (SOC: p=144, S2P: p=200). Dominance is for squared-error; production uses accuracy (strong heuristic).

**4. Fisher Information (Motivation — Layer A/B).** For Gaussian class-conditional, Fisher for precision (1/σ²) depends on FOURTH moment, informative after means stabilize. Layer A: Gaussian surrogate motivates why Phase 2 persists. Layer B: ρ_variance ≈ +0.35 at 18/18 confirms deployed estimator exhibits pattern. §3.4. Fisher is MOTIVATION, not proof. Lineage: Fisher 1925, Amari 1985. Layer A/B framing is novel.

**5. Discriminative Metric Learning (Diagonal Family).** Per-dimension weights w_DK maximizing classification accuracy. K(f,μ) = Σ_j w_j(f_j−μ_j)². Concentrates ~5.5→~4.0 effective dims (K34). +3.2pp (N=500) → +5.4pp (N=4000). §3 Eq. 4-diagonal, §3.3, §3.4. Lineage: Mahalanobis 1936, Weinberger & Saul 2009. Diagonal constraint: off-diagonal <1pp (D2/D3).

**6. Conservation Invariant** (α·q·V ≥ θ_min, **α = cumulative category coverage = c_d/C**). Runtime guarantee against silent degradation. Auto-pause on violation. EU AI Act Article 14 backing. §5, §9, §16. Three-judge validated (invariant *form*; the constant 23.53 is empirically calibrated, see §9). q = rolling verified accuracy over 400 decisions. θ_min = 23.53/(α×V).

**7. Re-Convergence Theorem** (γ > 1). Recovery faster than initial calibration. γ > 1 ⟺ ε_firm > 0.125. Four proof paths. §3.2, §10.14. Novel to this work.

**8. Nearest-Neighbor Novelty.** novelty(f) = min ‖f − f'‖ over H(c,a). Leading change indicator. DK re-estimation trigger. r=+0.43 with DK improvement (RATE-6). §3.6. Four failure modes documented.

**9. Holdout Non-Inferiority (Promotion Gate).** New scorer must match current on holdout: accuracy_new ≥ accuracy_current − ε. Operational guardrail. §3.5. ε=1.0pp, δ=2.0pp per-category, N_min=20. Lineage: clinical trials, A/B testing.

**10. Rolling Verified Accuracy.** q(t) = correct/total over last 400 verified. Calibration-independent. Robust across kernels. §5, §9, §16. SE ≈ 3.6pp at q≈0.85.

**11. Judgment Memory (Positioning — Fourth Cognitive Type).** The composition of abstractions 1-10 produces a memory type not addressed by CoALA's episodic/semantic/procedural taxonomy: per-factor decision quality measurement from verified outcomes, compounding with use, producing safety proofs. Centroid geometry = WHERE decisions cluster (episodic analogue). Noise fingerprint = WHICH factors are signal vs noise (no analogue in standard three). Conservation law = WHEN autonomous action is safe (no analogue). Signal-confidence inversion = the empirical finding that trusted factors have highest σ. See cga_arxiv v7.5 §1.1, claims registry v7 B11/B12.

**How they compose:** 1-2 = scoring + learning foundation (Phase 1). 5 = deployment-specific weights (Phase 2). 3 = connects Phase 1→2 safely (shrinkage). 4 = motivates why Phase 2 persists (Fisher A/B). 8 = detects when re-estimation needed (novelty). 9 = validates before deployment (promotion gate). 6+10 = monitors health (conservation + accuracy). 7 = recovery accelerates (re-convergence). 11 = the positioning frame for what 1-10 collectively produce — judgment memory as fourth cognitive type.

---

## 3. Core Equations (VALIDATED)

*Subsections: Eq. 4-final (scoring) · Eq. 4b-final (learning) · Available Kernels ·
§3.1 Convergence Analysis · §3.2 Re-Convergence Theorem · §3.2a DK-STALE ·
§3.3 DiagonalKernel Surface · §3.4 Two-Phase Learning · §3.5 Batch Pipeline ·
§3.6 Novelty Model · Eq. IKS · Eq. T\**

### Eq. 4-final — Scoring

```
P(a|f,c) = softmax(−K(f, μ[c,a,:]) / τ)
```

- f ∈ [0,1]^d: factor vector from graph traversal (d=6 for SOC, d=8 for S2P)
- μ[c,a,:] ∈ [0,1]^d: profile centroid for category c, action a
- K: kernel function. See kernel table below.
- τ = 0.1: temperature (V3B validated, ECE=0.036). Fixed. Never change.
- Softmax over n_act actions: P sums to 1, selected action = argmax

**Two production kernels (v6.0):**

```
L2 (production kernel):
  K(f, μ) = ‖f − μ‖² = Σ_j (f_j − μ_j)²
```

**DiagonalKernel — preprocessing-dependent, not a safe default (v20 status):**

```
DiagonalKernel was investigated as a scoring kernel:
  K(f, μ) = (f − μ)ᵀ W (f − μ) = Σ_j w_j (f_j − μ_j)²
  where W = diag(1/σ²), σ_j = per-factor noise
  
  Showed +13.2pp on synthetic heterogeneous noise (V-MV-KERNEL-HET)
  and +7.67pp characterized at NR=5.0 (UNI-DK-01 v5.3).
  On five real UCI datasets (DK-VERIFY, 300+ cells + DK-VERIFY-SUB
  500+ cells with 50-seed confirmations): preprocessing-dependent.
  Some cells positive (Bank Marketing min-max: +10.0pp, 50/50 seeds).
  Others negative (Credit robust: −0.8pp). The synthetic heterogeneity
  mechanism (advantage scales with NR) does not operate on real data
  (slopes flat on all admissible datasets). No general predictor
  established (best: effective dimensionality r=−0.51, 60% LOO accuracy).
  DiagonalKernel is a deployment-specific option requiring per-deployment
  validation. L2 retained as safe production default.
  The KernelSelector rule (noise_ratio > 1.5 → DK) is RETIRED.
```

**Interpretation:** Each action has a prototype factor pattern (the centroid). The action
whose prototype is closest to the observed factors wins under L2 distance. Temperature τ=0.1 controls decision sharpness — validated as optimal by V3B (ECE=0.036 vs 0.19 at τ=0.25). The per-factor noise fingerprint (σ) survives as a diagnostic — it surfaces signal-confidence inversion and judgment biases but does not weight the scoring kernel.

---

### Eq. 4b-final — Centroid Learning

```
When correct (a_pred = a_gt) — CONFIRM path:
  μ[c, a_pred, :] ← μ[c, a_pred, :] + η_confirm_eff · G(f, μ[c, a_pred, :])   [pull]

When incorrect (a_pred ≠ a_gt) — OVERRIDE path, dual update:
  μ[c, a_pred, :] ← μ[c, a_pred, :] − η_override_eff · G(f, μ[c, a_pred, :])  [push wrong away]
  μ[c, a_gt, :]   ← μ[c, a_gt, :]   + η_confirm_eff  · G(f, μ[c, a_gt, :])    [pull correct toward]
  All other action centroids in category c: unchanged.

η_confirm_eff = η_confirm / (1 + n[c, a_pred] · decay_rate)
η_override_eff = η_override / (1 + n[c, a_pred] · decay_rate)

G(f, μ) = kernel gradient:
  L2Kernel:       G(f, μ) = (f − μ)
  DiagonalKernel: G(f, μ) = W · (f − μ)    — pushes harder on clean dimensions

Where:
  a_pred = predicted action (argmax of P(a|f,c))
  a_gt   = ground truth action (from verified analyst outcome)
```

- **η_confirm = 0.05:** confirm-path learning rate (clean signal, full rate)
- **η_override = 0.01:** override-path learning rate (noisy signal, attenuated 5×)
- η_neg = 0.05: canonical base rate. **FORBIDDEN: η_neg=1.0 — ECE=0.49 (PROD-4b).**
- n[c,a]: cumulative verified-outcome count for (category, action) pair
- decay_rate = 0.001: count-based decay — stability increases with experience
- **INVARIANT:** μ ← clip(μ, 0.0, 1.0) after every update (V2 validated, mandatory)
- **INVARIANT:** Masked dimensions (factor_mask) do NOT update — gradient zeroed.

**Asymmetric η — the P0 fix (March 19, 2026):**

9-persona LLM-judge stress test found 13-27pp centroid degradation from realistic analyst
override quality (q̄=0.60-0.70). The override path carries noise from analyst errors.
η_override=0.01 attenuates this by 5×. Validated across 24 personas (1C quality sweep):
at q̄=0.57 (worst quality): +0.5pp with η_override=0.01 (no degradation); without: -9pp.
Corr(noise_ratio, diagonal_advantage) = 0.990 across 4 healthcare personas.

**UNI-DK-01 v5.3 confirmation (April 19, 2026):** at NR=5.0, η_override=0.01 maintains
positive learning gap throughout the 5000-decision trajectory (+3.49pp learning
contribution to +7.67pp asymptotic gap). Previous "negative learning at low NR"
reported in v_mv_kernel Deliverable 1 is retracted — measurement artifact of cumulative
averaging (see §3.3 methodology note).

**Formula (diagnostic — global default 0.01 is the validated value):**
```
η_override* ∝ (2q̄ − 1) / (2σ²_q + signal)
```
Directionally correct, ~2× overestimate vs empirical optimum. Q5 persona sweep is
ground truth; per-deployment TD-034 sweep confirms.

**Bug fix note (March 15, 2026):** Prior to this fix, the incorrect branch pushed ALL
action centroids in category c away from f (including the ground truth centroid). This
caused centroid degradation. SHIFT-2 validated: -9.0% accuracy lift before fix,
+2.7% after fix (noise=0, δ=0.10, warmup=1000).

**Interpretation:** Correct outcomes pull the predicted centroid toward the observed
factor pattern using the kernel-aware gradient. Incorrect outcomes push the wrong
centroid away AND pull the correct centroid closer, both at the attenuated override
rate. The asymmetry between confirm (0.05) and override (0.01) reflects that analyst
overrides are noisier than confirmations — the system trusts agreements more than
disagreements. Count decay ensures early decisions carry more weight per-update
than later decisions — the system front-loads learning and stabilizes with experience.

---

### Available Kernels

| Kernel | K(f,μ) | When to Use | Accuracy | Noise Ceiling |
|---|---|---|---|---|
| **L2 (cold-start)** | ‖f − μ‖² | noise_ratio ≤ 1.5. Factors in [0,1]. | **97.89%** (centroidal) | σ ≤ 0.157 |
| **DiagonalKernel** | **(f−μ)ᵀW(f−μ), W=diag(1/σ²)** | **Preprocessing-dependent — positive on some dataset/convention cells (Bank +10pp), negative on others (Credit robust −0.8pp). Not a safe default.** | **+13.2pp synthetic peak; +10.0pp Bank min-max (real, 50-seed stable); preprocessing-dependent on other datasets** | **Requires per-deployment validation** |
| Cosine | 1 − cos(f,μ) | Pre-normalized factors | 96.42% | — |
| Dot product | −f·μᵀ | **DO NOT USE.** Magnitude confounding. | 61.00% | — |
| ShrinkageKernel | (f−μ)ᵀΣ̂⁻¹(f−μ) | **DEPRIORITIZED to v7.0.** Off-diagonal adds <1pp. | Same as Diagonal | — |

**The DiagonalKernel investigation (V-MV-KERNEL + UNI-DK-01 v5.3) — BOUNDARY DEFINED (preprocessing-dependent, L2 retained as default):** [v20]

Two large factorials (1,890 cells total) measured the DK advantage on SYNTHETIC data:

| Domain | L2 (hetero) | Diagonal (hetero) | Synthetic Lift |
|---|---|---|---|
| SOC | 79.5% | 92.7% | **+13.2pp** |
| S2P | 42.2% | 49.0% | **+6.8pp** |
| Characterized (NR=5.0) | — | — | **+7.67pp** |

**On five real UCI datasets under three preprocessing conventions (DK-VERIFY + DK-VERIFY-SUB, 800+ total cells)**, the advantage is preprocessing-dependent: some dataset/convention cells are positive (Bank Marketing min-max: +10.0pp, 50/50 seeds positive, stable), others negative (Credit robust: −0.8pp). The synthetic heterogeneity mechanism (advantage scales monotonically with NR) does not operate on real data — slopes are flat on all admissible datasets. No general predictor was established (best: effective dimensionality r = −0.51, conditional rule 60% leave-one-out accuracy). DiagonalKernel is a deployment-specific option requiring per-deployment validation, not a safe default. L2 is the production kernel because its 36.89pp advantage over dot product is preprocessing-independent.

The per-factor weighting investigation (DiagonalKernel) was a thorough, honestly-reported finding that sharpened what the architecture IS (L2 geometry as safe default) by establishing what requires caution (per-factor kernel weighting is preprocessing-dependent).

| Kernel | GREEN | AMBER | RED |
|---|---|---|---|
| L2 | σ_mean ≤ 0.105 | 0.105 < σ ≤ 0.157 | σ > 0.157 |

**Noise ceiling is also three-variable (V-B3, March 21):**

The corruption vector is V × (1−q̄) × η_override, not σ alone. At low volume (V=50),
even σ=0.190 doesn't corrupt centroids (too starved for bad overrides). At V=200 +
σ=0.157 + q̄=0.60, degradation occurs. Low volume is protective (same mechanism as
2D starvation finding).

The 36.89pp gap between dot product and L2 on identical data (EXP-C1) remains the
foundational kernel finding. The per-factor weighting investigation (DiagonalKernel) was a thorough, honestly-reported negative that sharpened what the architecture IS (L2 geometry) by establishing what it ISN'T (per-factor kernel weighting).

---

### §3.1 — Convergence Analysis for Eq. 4b-final

> **Note:** The convergence analysis in §3.1 is unchanged from v9.1. The asymmetric η
> (η_confirm vs η_override) modifies the RATE but not the FORM of convergence. The mean
> error dynamics become E[e_n] ≈ (1−η_eff)^n × e_0 where η_eff is the effective rate
> accounting for the mix of confirms and overrides. N_half ≈ 14 at η_confirm=0.05
> remains correct for the confirm path; the override path converges more slowly
> (N_half ≈ 69 at η_override=0.01). The blended N_half depends on the confirm/override
> ratio, which varies by analyst quality. At q̄≥0.70 AND σ≤0.157 (L2) /
> σ≤0.25 (Diagonal): N_half≈14 remains the correct claim (most updates are confirms).

#### Eq. CONV — Mean Error Dynamics
```
E[e_n] = (1 − η)^n × e_0
where e_0 = μ_0 − μ* (initial prior mismatch — expert guess vs firm reality)
```

**Precision:** Under constant step size η, the iterate does NOT converge almost
surely to μ*. It forms a geometrically ergodic Markov chain around the fixed
point with stationary distribution whose spread is O(√η). The mean contracts
as stated; the iterates track a STATIONARY NEIGHBORHOOD, not a point.

**Half-life of mean error:**
```
N_half = ln(2) / ln(1/(1−η)) ≈ ln(2) / η    for small η
```

At η = 0.05: N_half ≈ 14 verified decisions per (c, a) pair.

---

#### Eq. MSE∞ — Steady-State MSE
```
E[‖e_∞‖²] = η / (2 − η) × tr(Σ_f)
```

where Σ_f is the d×d factor covariance matrix for (c, a_GT). The component
recursions decouple: each dimension evolves as an independent scalar SA.
Cross-covariances in Σ_f affect the joint distribution but NOT the scalar
MSEs — only the trace enters. [Three-judge confirmed: Opus verified component
independence; GPT confirmed the Lyapunov equation derivation.]

**IMPORTANT:** Use tr(Σ_f), not d·σ²_f. Per-factor variances differ in
practice: asset_criticality likely has higher variance than device_trust.
tr(Σ_f) = Σ_j σ²_{f,j} handles heterogeneous variances correctly.

At η=0.05, d=6, tr(Σ_f) ≈ 0.24 (estimated from FX-1-PROXY-REAL factor
distributions): E[‖e_∞‖²] ≈ 0.006, or ‖e_∞‖ ≈ 0.08 (~8% of [0,1] range
per component average).

---

#### Eq. N_CONV — Convergence Time to Calibration Neighborhood
```
N_converge(ε) = ln(‖e_0‖ / max(ε, √(η·tr(Σ_f)/(2−η)))) / η
```

Time for mean error to enter steady-state neighborhood. Calendar conversion:
```
T_calendar(c, a) = N_converge / (V × π_c × f_v × π_{a|c})
```

where V = alerts/day, π_c = category fraction, f_v = verification rate,
π_{a|c} = fraction of category c alerts where GT action is a.

---

#### Conditions and Limitations

**[0,1] Projection:** Projection onto [0,1]^d is non-expansive and does not
change the convergence rate for interior points (projection inactive at μ*).
Consequential when μ* is near boundary: effective step size in projected
dimension reduces to η/2. Quantitative condition: projection matters when
‖μ* − ∂[0,1]^d‖ < c√(η·σ²_f). For typical SOC parameters, this affects
the top/bottom 5-10% of factor value range. [Opus: Borkar 2008, Chapter 5.]

**Push-away coupling:** No direct coupling — pull-toward and push-away modify
distinct centroid vectors. Indirect coupling through confusion matrix:
E[Δμ_a] = η_pos × P(a_GT=a) × E[f−μ_a | a_GT=a]
− η_neg × Σ_{b≠a} P(a_pred=a, a_GT=b) × E[f−μ_a | a_pred=a, a_GT=b]

The limiting geometry balances attraction to true members and repulsion from
confused non-members. Generally beneficial (increases inter-centroid separation).
[GPT: margin expansion. Opus: drift formula above.]

**Centroid retirement pathology [Opus finding]:** With η_neg=0.05 and repeated
misclassification for the same (c,a) pair, the wrong centroid can be pushed
far from all data — effectively retiring that action class. Monitor: for each
(c,a), check that ∃ verified decisions (f, a_GT=a) with ‖f − μ[c,a,:]‖ < D_support.
If no recent decision is within D_support, flag as "out of support."

**Non-i.i.d. factors (campaign clustering):** The i.i.d. result is a baseline.
Under temporal correlation (campaign-clustered alerts), effective variance
inflates:
σ²_eff = σ²_f × (1 + 2 Σ_{k≥1} ρ_k)

For AR(1)-like dependence: n_eff ≈ n(1−ρ₁)/(1+ρ₁). The convergence rate
(1−η)^n is preserved in expectation, but variance is inflated by
autocorrelation. [GPT: effective sample size. Opus: Borkar 2008 Chapter 6.]

**Non-stationarity:** Under drifting target μ*(t), tracking error:
E[‖μ_n − μ_n‖] ≈ √(η·tr(Σ_f)/(2−η)) + ‖dμ/dt‖ / η

First term: steady-state noise (decreases with η). Second term: tracking lag
(increases with η). Constant step size is an advantage: the centroid tracks
a drifting target. Decaying step size would freeze the centroid. Monitor:
rolling mean of (f_n − μ_n); non-zero mean indicates distribution shift.

**Validation status:** Eq. CONV, MSE∞, N_CONV confirmed by three judges as
known results of projected constant-step-size stochastic approximation.
Not novel math — novel application to SOC centroid learning.

**Experiment:** B-1 sweep (extends SHIFT-2): η_pos × ‖e_0‖ × σ²_f × N ×
{isolated pull, push-away coupled, boundary targets, temporally clustered,
correlated factors} at 50 seeds. ~20,000 runs. Validates theory matches
simulation within 10%.

### §3.2 — Re-Convergence Theorem

**Context:** After initial deployment (Phase 1), the system converges to operational
accuracy in N_half,1 decisions. After an environmental disruption (Phase 2), the system
re-converges in N_half,2 decisions. The re-convergence speed ratio γ = N_half,1 / N_half,2
is the temporal compounding claim: γ > 1 means re-convergence is faster than initial
calibration.

---

**Two-Phase Setup**

```
Phase 1 — Initial deployment:
  μ₀ = μ_canonical + ε_firm       (expert-initialized centroid + firm-specific deviation)
  D₁ = ‖ε_firm‖                   (Phase 1 initial distance from firm ground truth GT₁)
  P₁ = cold factor vector distribution (no accumulated W2 graph edges)
  N_half,1 = min{n ≥ w : rolling_w(correct) ≥ θ}

Phase 2 — After category-sparse disruption:
  GT₂ = GT₁ + Δ                   (disruption shifts c_d of C categories)
  μ_T1 ≈ GT₁                      (Phase 1 has converged)
  α_disrupt = c_d / C              (fraction of alert categories disrupted — re-convergence quantity, DISTINCT from the conservation-law α = category coverage; see D1/v18)
  α_tensor = 4 / (C·A·d) ≈ 0.03  (fraction of tensor elements disrupted)
  P₂ ≠ P₁                         (enriched factor vectors from T₁ W2 edges)
  N_half,2 = min{n ≥ w : rolling_w(correct) ≥ θ} from Phase 2 start

Production values: C=6, A=4, d=6, c_d=2, w=10, θ=0.85
```

---

**The Rolling-Window Shortcut (Central Mechanism)**

In Phase 2, (1 − α_disrupt) = 4/6 ≈ 0.67 of alert decisions come from undisrupted categories.
These decisions are immediately correct (μ_T1 ≈ GT₂ for undisrupted categories).

The effective Phase 2 accuracy threshold for disrupted categories is:

```
p_d★ = (θ − (1 − α_disrupt)) / α_disrupt
     = (0.85 − 0.67) / 0.33
     ≈ 0.55
```

Phase 2 only needs disrupted categories to reach 55% correctness (not 85%) for the
rolling window to declare N_half,2. Phase 1 had no such shortcut — all C categories
started cold from ε_firm.

---

**Theorem (Re-Convergence Speed — April 8, 2026)**

```
γ > 1   ⟺   ε_firm > ε_firm★

where:

ε_firm★ = α_disrupt · ‖Δ‖ / (1 − α_disrupt)
         = (2/6) · 0.25 / (1 − 2/6)
         = 0.0833 / 0.6667
         ≈ 0.125

[Formula corrected April 8, 2026: θ cancels in correct derivation.
 Previous version had α·‖Δ‖·θ/(θ−(1−α)) = 0.387 for production values — wrong.
 Coding session confirmed via gae/convergence.py implementation. Diff = 0.003.]
```

**Parameters:**
- ε_firm: firm-specific deviation from canonical centroid (every real deployment has ε_firm > 0)
- α_disrupt = c_d/C: fraction of alert categories disrupted (≈ 0.33 for a typical campaign)
- ‖Δ‖: disruption magnitude per affected tensor element (≈ 0.25 for a new attack campaign)
- θ: operational accuracy threshold (= 0.85)

**Production range:** ε_firm ≈ 0.15–0.40. Threshold ε_firm★ ≈ 0.125.
Every real deployment clears the threshold.

**Simulation range:** ε_sim = 0.05 (oracle separation experiments). Below threshold.
This correctly predicts γ < 1 in simulation, as observed.

---

**Three Structural Proof Paths (all confirmed independently)**

*Path 1 — Geometric (primary):*
Phase 1's convergence challenge (all C categories, from ε_firm) exceeds Phase 2's
challenge (c_d disrupted categories, to reduced target p_d★) when ε_firm > ε_firm★.
Directly gives the threshold condition.

*Path 2 — Dimensional:*
Phase 1 must calibrate C categories. Phase 2 must reconverge c_d categories while
(C − c_d) categories remain correctly calibrated and contribute free rolling-window
accuracy. Effective convergence dimension ratio: C / c_d = 3.
Lower bound: γ ≥ (C/c_d) · (θ / (θ − (1−α_disrupt))) ≈ 4.6 in the idealized limit.

*Path 3 — η₋ Trap Avoidance:*
Phase 2 maintains η_eff near η₊ = 0.05 because 67% of decisions are undisrupted
(immediately correct → confirm path). Phase 1 with large ε_firm may enter the η₋ trap
where low initial accuracy → η_eff ≈ η₋ = 0.01 → learning near-stalled.
Effective learning rate ratio: η_eff,2 / η_eff,1 > 1 when ε_firm is large.
This means true production γ exceeds the geometric lower bound.

---

**Conditions (Required for Theorem to Hold)**

```
(1) Category-sparse disruption: c_d << C (few alert types disrupted at once)
    Realistic: ransomware campaign disrupts 2 of 6 categories, not all 6.

(2) Warm-started centroids: μ_T1 ≈ GT₁
    Always true when Phase 1 has converged (N_half,1 was reached).

(3) ε_firm > ε_firm★ ≈ 0.125
    Estimated from deployment data: 0.15–0.40 for real SOC environments.
    Verifiable from centroid_distance_to_canonical logged per decision.

(4) Same-regime factor vectors (P₁ and P₂ from same distribution)
    When disruption also shifts factor vector distribution (e.g., new attack changes
    alert signatures), Lemma B applies: PatternHistory enrichment adapts the factor
    distribution. T_adapt decisions needed for full enrichment effect.
```

---

**N_half Measurement Gap (Practical Note)**

N_half conflates two distinct quantities:
- Centroid convergence: how far μ has moved toward GT (what the theorem models)
- Vector separability: how well factor vectors separate actions at the oracle boundary

For high-quality factor vectors (high Day-1 accuracy), N_half may fire before the centroid
has genuinely converged to GT — making N_half too short and γ measurements unreliable.

**The correct convergence signal for EXP-G1 is centroid_distance_to_gt:**
```
dist(t) = ‖μ(t) − GT‖_F
```
This decreases monotonically under production learning dynamics regardless of factor
vector quality or noise seed. Confirmed across all oracle separation experiments
(v6/v8/v11/v2/v3/final, April 8, 2026). EXP-G1 measures γ as the ratio of centroid
distance convergence rates, not as a N_half ratio.

---

**Simulation Validation (Binary Prediction)**

```
Oracle separation v8 (ε_sim = 0.05 < ε_firm★ = 0.125):
  Opus: N_half,1=25, N_half,2=35, γ=0.714 < 1  ✓  (theorem predicts γ < 1)

Oracle separation v3 Opus (ε_sim = 0.20 > ε_firm★ = 0.125):
  Opus: N_half,1=125, N_half,2=121, γ=1.033 > 1  ✓  (theorem predicts γ > 1)
```

Binary prediction correct in both directions. Full record:
`synthetic_data_generation_analysis_v2.md`

---

**Equation Tags**

```
Eq. GAMMA-THEOREM:  γ > 1 ⟺ ε_firm > α_disrupt · ‖Δ‖ / (1 − α_disrupt)  [corrected]
Eq. GAMMA-THRESH:   ε_firm★ = α_disrupt · ‖Δ‖ / (1 − α_disrupt) ≈ 0.125  [corrected April 8]
Eq. GAMMA-P_D:      p_d★ = (θ − (1 − α_disrupt)) / α_disrupt ≈ 0.55
Eq. GAMMA-RATIO:    γ = N_half,1 / N_half,2   (threshold-crossing time ratio)
Eq. GAMMA-DIST:     dist(t) = ‖μ(t) − GT‖_F  (preferred EXP-G1 metric)
```

**Proof sources:** GPT-4.1, Claude Opus 4, Grok 3, Gemini 1.5 Pro (April 8, 2026).
*Note: LLM verification of a mathematical proof (checking whether a derivation is algebraically valid)
is distinct from LLM-generated correctness labels (K3). The former is admissible — the proof is
deterministic and independently verifiable; four independent LLMs arriving at the same result is a form
of peer verification. The K3 bright line bars LLMs from generating the correctness signal for decision
validation, not from checking algebra.*
See Claims Registry v6.3 §B.5 CLAIM-GAMMA-THEOREM for the full formal statement with
conditions and commercial tier designation (Tier 2, QUALIFIED v6.3).

---

**Experimental Characterization (May 2026 — reconvergence_v2_faithful.py)**

Production-faithful experiment (270 runs: 6 ε values × 3 kernel
modes × 15 seeds. C=6, A=4, d=6. DK-aware update gradient.
Conservation gate active. Rolling σ² estimation for DK-estimated.)

Results at c_d/C = 0.33, Δ = 0.25:

| Kernel | γ (ε > 0.125) | Interpretation |
|---|---|---|
| L2 | **1.18 ± 0.98** | Effect is real. ~18% faster recovery. |
| DK-fixed (correct σ) | **1.07 ± 0.61** | DK gradient dampens effect. |
| DK-estimated (stale σ) | **0.94 ± 0.18** | **Stale DK weights REVERSE effect.** |

Binary prediction confirmed: 85% of ε < 0.125 runs give γ < 1 (L2).
57% of ε > 0.125 runs give γ > 1 (L2). 100% convergence all conditions.

The dimensional lower bound γ ≥ 4.6 (Path 2) is not reached under
production scorer dynamics due to: (a) η asymmetry (5:1 confirm/
override ratio constrains gradient magnitude), (b) conservation gate
pausing (delays Phase 1 proportionally more than Phase 2), (c) centroid
clipping to [0,1].

**Reconciliation with EXP-G1 v3:** EXP-G1 v3 reported γ_centroid = 1.02
(L2) and DK 1.9× slower. The DK finding is consistent with DK-estimated
γ = 0.94 (stale weights). The L2 finding (1.02 vs 1.18) suggests
additional production mechanisms (referral engine, AgentEvolver) further
dampen the effect. Definitive measurement requires running with the
production ProfileScorer.

**Conclusion:** The theorem's binary prediction is experimentally
confirmed. The effect size is moderate (γ ≈ 1.2 L2), not negligible
(γ ≈ 1.0) and not large (γ ≥ 4.6). DK stale weights are an
independent finding (see §3.2a DK-STALE below).

---

### §3.2a — DK-STALE: Stale DiagonalKernel Weights After Disruption

**Finding:** DiagonalKernel weights estimated pre-disruption cause
1.3–1.9× convergence slowdown during recovery. Mechanism: DK weights
W = diag(1/σ²) concentrate the update gradient on factors that were
discriminative pre-disruption. Post-disruption, those factors may no
longer be the most discriminative, causing the gradient to push
centroids in suboptimal directions.

**Evidence:**
- reconvergence_v2_faithful.py: DK-estimated γ = 0.94 vs L2 γ = 1.18
  (1.3× slower). Stale σ drift: 5–6% per disruption cycle.
- EXP-G1 v3: DK 1.9× slower than L2 after disruption (production scorer).

**Operational implication:** After disruption detection (conservation
margin decline), KernelSelector must reset to L2. DK re-enabled after
~200 post-disruption decisions stabilize σ estimates. This procedure
is encoded in Framework v4 ResetPolicy and is safety-critical.

**Relationship to Re-Convergence Theorem:** DK-STALE is INDEPENDENT
of the γ > 1 theorem. The theorem is proven for L2 kernel. DK-STALE
characterizes what happens when DK is used during recovery without
reset. Both findings originate from the same experimental program.

**Claim:** CLAIM-DK-STALE, Tier 2. See Claims Registry v6.3.

---

### §3.3 — DiagonalKernel Characterization Surface (UNI-DK-01 v5.3)

**Context:** V-MV-KERNEL-HET (March 21, 2026, 390 cells) established the DK advantage
on heterogeneous SOC data at "+13.2pp peak." Deliverable 1 attempted to decompose that
advantage into cold-start scoring-geometry vs. learning components using
`v_mv_kernel_rerun_v1.json` cumulative-accuracy data. That decomposition was
retracted in v14 — cumulative averaging produced paradoxical ratios (e.g.,
cold_start_pct > 100% at low NR, "negative learning" artifacts) that were measurement
artifacts, not real phenomena.

UNI-DK-01 v5.3 (April 19, 2026) is the correct characterization: a controlled 1500-cell
experiment with point-in-time (instantaneous) accuracy measurement via a frozen-centroid
no-learning scorer for cold-start and a 400-decision rolling deque for asymptotic.

**Parameterization:**
- NR ∈ {1.0, 1.5, 2.0, 3.0, 5.0}  (5 noise ratios)
- q̄ ∈ {0.57, 0.65, 0.75, 0.85, 0.95}  (5 analyst quality levels)
- 30 random seeds per cell
- Both kernels (L2, DiagonalKernel) run on byte-identical event streams
- 5000 decisions per cell, 25% verification rate
- Fixed mean-σ = 0.175 across all NR levels (resolves NR/mean-σ confound from
  V-MV-KERNEL which had variable mean-σ)
- σ profile: linear ramp with specified NR at fixed mean (e.g., NR=5.0 →
  σ = [0.058, 0.105, 0.152, 0.198, 0.245, 0.292], mean=0.175)

**Methodology (replaces cumulative decomposition from Deliverable 1):**

```
Phase 1 — Cold-start measurement (no-learning scorer):
  Instantiate fresh ProfileScorer with frozen mu_init, no scorer.update() calls.
  Score decisions 0-399 only.
  cold_start_accuracy = n_correct / 400.
  This is the pure scoring-geometry accuracy with no learning contamination.

Phase 2 — Learning trajectory (standard scorer):
  Instantiate fresh ProfileScorer with mu_init, standard score+update loop.
  Run full 5000 decisions.
  inst_accuracy_at[K] = sum(rolling_deque(maxlen=400)) / 400 at checkpoint K.
  asymptotic_accuracy = inst_accuracy_at[5000] (last 400 decisions, instantaneous).

Decomposition (mathematically exact):
  cold_start_gap  = DK cold_start_accuracy − L2 cold_start_accuracy
  asymptotic_gap  = DK asymptotic_accuracy − L2 asymptotic_accuracy
  learning_gap    = asymptotic_gap − cold_start_gap
```

Both scorers see byte-identical events (RNG-seeded for reproducibility). The decomposition
`learning_gap = asymptotic_gap − cold_start_gap` is mathematically exact because both
terms are unbiased gap estimators on the same event distribution, evaluated at different
scorer states.

**Decomposition Table (v5.3 results):**

| NR | Cold-start gap | Learning gap | Asymptotic gap | Cold-start % of asymptotic |
|---|---|---|---|---|
| 1.0 | 0.00pp (std=0) | 0.00pp | 0.00pp | — |
| 1.5 | +0.53pp | +0.19pp | +0.72pp | 73.5% |
| 2.0 | +1.50pp | +0.49pp | +1.99pp | 75.5% (peak) |
| 3.0 | +3.09pp | +1.35pp | +4.43pp | 69.6% |
| 5.0 | +4.18pp | +3.49pp | +7.67pp | 54.5% |

**Standard errors:** SE on asymptotic gap ranges from 0.085pp (NR=1.5) to 0.191pp (NR=5.0)
with 150 paired cells per NR. All D-checks (§8) operate on robust point estimates.

**Key findings:**

1. **NR=1.0 mathematical identity:** DK collapses to L2 at uniform σ, confirmed empirically
   with gap=0.00pp and std=0 across all 150 paired cells. Strongest possible validation
   of the math base.

2. **Monotonic DK advantage:** Asymptotic gap strictly increasing in NR: 0.00 → 0.72 →
   1.99 → 4.43 → 7.67pp. No tolerance needed for monotonicity.

3. **Cold-start is the larger contributor across all noise regimes**, but its FRACTION
   of asymptotic gap varies non-monotonically:
   - Peaks at NR=2.0 (75.5%) — scoring geometry dominates DK's advantage at moderate
     heterogeneity
   - Weakens at NR=5.0 (54.5%) — learning grows faster than cold-start at extreme
     heterogeneity, so scoring-geometry's share declines even as its absolute value grows
   - Narrative implication: v14 replaces "cold-start dominates at high NR" (from
     Deliverable 1) with "cold-start is the larger contributor across all noise regimes,
     with both cold-start and learning growing in absolute terms as NR rises."

4. **Positive learning at every NR:** Learning gap is +0.19 to +3.49pp across NR=1.5–5.0.
   No "negative learning" anywhere. The v4.2 (cumulative) finding of negative learning
   at low NR is **retracted** — it was a difference-of-cumulative-averages artifact.

5. **q̄-invariance of cold-start confirmed:** max q̄-std (std of per-q̄ group means
   of cold_start_gap) = 0.285pp at NR=2.0. Under v4.2 cumulative measurement this
   was 1.22pp (FAIL). Under v5.3 frozen-scorer measurement: PASS by 3.5× margin.
   The cold-start gap is genuinely q̄-independent because scoring with frozen centroids
   is deterministic given the event stream.

**DiagonalKernel Calibration Finding (NEW, unexpected):**

| NR | L2 ECE (τ=0.1) | DK ECE (τ=0.1) | Ratio |
|---|---|---|---|
| 1.0 | 0.055 | 0.055 | 1.0× |
| 1.5 | 0.053 | 0.148 | 2.8× |
| 2.0 | 0.051 | 0.223 | 4.4× |
| 3.0 | 0.046 | 0.325 | 7.0× |
| 5.0 | 0.041 | 0.420 | 10.4× |

L2 is well-calibrated and improves with NR (ECE stays 0.04–0.06). DK is severely
miscalibrated at high NR (ECE 0.42 at NR=5.0). When DK reports confidence 90%, the
actual accuracy on those decisions is far below 90%.

**Mechanism.** W = diag(1/σ²) normalized so max weight = 1. At NR=5.0:
W = [1.00, 0.31, 0.15, 0.09, 0.06, 0.04]. Four of six factors contribute <15% of the
weight of the dominant factor. DK's effective dimensionality is ~3 (factors with
w > 0.1). Reduced effective dimensionality sharpens the softmax: predictions become
pushed toward 0 or 1 rather than spread across actions. argmax accuracy rises;
confidence calibration degrades.

This is a fundamental property of inverse-variance weighting, not an implementation
defect. It affects ANY weighted-distance kernel with concentrated weights.

**Downstream consequences (addressed architecturally at each consumption point):**

| Consumer | Dependency on confidence | v14 resolution |
|---|---|---|
| KernelSelector (choosing L2 vs DK) | Would compare mean_conf between kernels | **NR-rule (Option A), no confidence used.** §3 kernel selection rule. |
| Conservation law q | q was per-decision confidence | **Rolling verified accuracy.** §9, §16 operational definition. |
| Auto-pause (AMBER) | Threshold on confidence | **Threshold on rolling verified accuracy.** §9 S6 update. |
| Analyst triage UI | Sort by confidence | **Sort by softmax entropy / confidence gap.** (Spec'd in gae_design v10.7.) |
| ProfileScorer output probabilities | Raw softmax output | Unchanged — downstream consumers pick up the relevant signal. |

Net effect: DK's miscalibration is real, but no production touchpoint consumes raw DK
confidence directly in v6.0. Accuracy-based signals (verified accuracy) and
distribution-shape signals (entropy, confidence gap) do not depend on DK calibration.

**v5.3 vs V-MV-KERNEL-HET number reconciliation:**

The v5.3 peak (+7.67pp at NR=5.0 asymptotic) is smaller than V-MV-KERNEL-HET's peak
(+13.2pp). They are at different operating points, not in conflict:

| Source | Cells | Mean σ | Peak condition | Peak DK advantage |
|---|---|---|---|---|
| V-MV-KERNEL-HET | 390 | variable (up to 0.30) | σ_level=0.30 SOC heterogeneous | +13.2pp |
| UNI-DK-01 v5.3 | 1500 | fixed at 0.175 | NR=5.0 (σ_max=0.292) | +7.67pp |

Lower mean noise in v5.3 → smaller absolute advantage. Both results are citable:
- +13.2pp: "up to" peak from V-MV-KERNEL-HET (higher mean noise)
- +7.67pp: characterized at controlled NR=5.0 mean-σ=0.175 (UNI-DK-01 v5.3)

**For the curve-based citation pattern used in innovation note and claims registry,**
see §7 (accuracy numbers) and the claims registry B3 row.

---

### §3.4 — Two-Phase Learning Formalization

**Profile State (v15 terminology — replaces "sufficient statistics" in deployed context)**

```
T₀ = {μ[c,a,:]}  — Order-0 profile state (centroid means)
     Shape: (C, A, d). Captures WHERE. Estimated by Eq. 4b-final (Phase 1).
     Transfers: YES (conservation-mediated ~2-7× warm-start acceleration; prior K19 +28pp NOT REPRODUCED — E-NEW-5 showed acceleration is conservation-mediated, not independent content transfer). Saturates: ~200 decisions per (c,a) pair.

T₁ = {w_DK[c,a,:]} — Order-1 profile state (discriminative precision weights)
     Shape: (C, A, d). Captures WHICH DIMENSIONS MATTER.
     Estimated by CoordinateDescentEstimator (Phase 2 batch re-estimation).
     Transfers: NO (-5.6pp, K19 — confirmed by E-NEW-5: unrelated transfer can be worse than cold start). Firm-specific. Ongoing (+3.2pp at N=500 → +5.4pp at N=4000).

**CLAIM-MOAT-B2 — the compounded routing advantage is firm-specific and non-transferable.**
Learning-curve vs learning-curve (not vs a frozen control): a simulated competitor trained on a different
firm's decision stream, evaluated on the incumbent's held-out decisions, never reaches sustained parity —
routing-quality gap 19.6 ± 5.4 pp (SOC), 5.7 ± 1.1 pp (DataOps), 0/5 seeds at parity. The gap closes only
when the competitor is handed ~half the incumbent's *labeled* verified stream; the asset is the verified-
outcome labels.
- **Operation:** a result about `update` iterated over a verified stream.
- **Signal tier:** T-real (exported production geometry) + T-sim (constructed competitor stream).
- **Maturity tier:** Tier 2 — designed experiment, not an observed market dynamic; live magnitude → T-pilot.
- **Honest bound:** non-transferable, not un-copyable — state migration collapses the gap; rests on the
  labels being unobtainable and a real switching cost. Judgment-level specificity holds for SOC; routing-
  level for all five. This is the canonical moat entry; see also the transfer decomposition (H-COALESCE)
  for the mechanism and the prior K19 +28pp retraction for what the moat is *not*.

```

Under the Gaussian surrogate, T₀ and T₁ correspond to sufficient statistics. In the deployed scorer (coordinate descent, not MLE), they are compact profile state parameterizing a weighted-distance decision rule. Sufficiency guarantees do not hold under model misspecification.

**Phase 1: MEAN_CONVERGENCE**

```
Eq. PHASE-1:
  For each verified decision (f, c, a_gt):
    μ[c,a,:] ← μ[c,a,:] + η(n) × G(f, μ[c,a,:])    [= Eq. 4b-final]
  
  Effective weights: w̃ = 1 (isotropic, Order 0 only)
  Termination: DecisionCountPolicy(n=200) per (c,a) pair. Freeze μ permanently.
```

Phase 1 saturation (K33): centroids closest to GT at ~200 decisions, then diverge (label-noise contamination). OPEN DESIGN QUESTION: quality-sensitive Phase 1 update (A4 action item). Default: don't solve — freeze early, let DK compensate.

**Phase 2: VARIANCE_LEARNING**

```
Eq. PHASE-2:
  Means frozen. Decisions buffered for batch re-estimation.
  Periodically (novelty-triggered or fixed interval):
    w_DK_new ← DKEstimator.estimate(buffer, μ_frozen)
    if PromotionGate.should_promote(w_current, w_new, holdout): deploy
    else: continue buffering
  Scoring: w̃ = α × w_DK + (1 - α)  [Eq. SHRINKAGE]
```

**Fisher-Inspired Asymmetry (Layer A / Layer B)**

**Layer A (Gaussian surrogate):** Fisher information for precision (1/σ²) depends on FOURTH moment. Scale information not exhausted by location. Motivates WHY Phase 2 persists.

**Layer B (empirical confirmation):** ρ_variance (Fisher-predicted ↔ actual DK weight ranking) ≈ +0.35 at ALL 18 checkpoints (K25, 3 seeds × 6 checkpoints, N=500-4000). The deployed estimator captures the structure Fisher predicts.

**The argument IS:** "Fisher-inspired asymmetry: Gaussian surrogate motivates why (Layer A), deployed estimator confirms (Layer B)." NOT: "Fisher proves DK improves."

**Three Error Channels**

```
Channel 1 (Scorer/DK): boundary error. ~8-10pp. Targeted by Phase 1 + Phase 2.
Channel 2 (Graph/Factors): factor quality. ~8-10pp. Targeted by W2 flywheel.
Channel 3 (Labels): noise error. ~4-5pp. Targeted by η attenuation.
```

Channels are mechanistically distinct, statistically coupled. Channel 3 contaminates Channel 1. Channel 2 affects Channel 1. Defense in depth (§9.1) addresses coupling.

---

### §3.5 — Batch Pipeline Mathematics

**The batch is the unit of deployed improvement.** Individual decisions add information to the buffer. Batches convert accumulated information into deployed quality.

**Seven lifecycle steps:**

1. ACCUMULATION: decisions buffer since last re-estimation.
2. TRIGGER: novelty accumulator or fixed interval.
3. COMPOSITION CHECK: novel_fraction ≥ 0.10, coverage ≥ 3/C, count ≥ 50.
4. ESTIMATION: CoordinateDescentEstimator (5 rounds, 400/cat, 9 candidates).
5. VALIDATION (Eq. PROMOTION-GATE):
   ```
   PASS iff:
     accuracy(w_new, holdout) ≥ accuracy(w_current, holdout) - ε    (ε = 1.0pp)
     ∀c: accuracy_c(w_new) ≥ accuracy_c(w_current) - δ             (δ = 2.0pp)
     ∀ active (c,a): |holdout ∩ (c,a)| ≥ N_min                     (N_min = 20)
   Holdout: 20% stratified. Engineering safeguard, not hypothesis test.
   ```
6. PROMOTION or REJECTION: deploy w_new, update w̃. Or keep w_current.
7. HISTORY: BatchHistory records everything. Enables rollback to any prior state.

---

### §3.6 — Novelty Model

```
Eq. NOVELTY:
  novelty(f, c, a) = min_{f' ∈ H(c,a)} ‖f - f'‖₂
  H(c,a) = last 300 decisions in same (c,a) pair. Cost: <1ms.
```

r=+0.43 correlation with DK improvement (RATE-6). Primary value: CHANGE DETECTOR (leading indicator — novelty spikes before accuracy drops).

**Four failure modes:** (1) Collision: novel patterns collide → measure vs existing prior. (2) Gradual drift: d_nn small → aggregate drift monitor. (3) Factor-version change: false spike → ResetPolicy suppresses, reduces α. (4) Correct detection: works correctly.

---

### Eq. IKS — Institutional Knowledge Score (v5.5)

```
IKS(t) = 100 · min( D(t) / κ*, 1.0 )

where D(t) = (1 / (n_cat · n_act)) · Σ_{c,a} ‖μ[c,a,:](t) − μ[c,a,:](0)‖₂
```

- μ(0): centroid tensor at bootstrap completion (1,200 synthetic calibration decisions)
- **Shape note (v10):** mean_drift averages over 24 (c,a) cells (6×4).
  D_MAX=0.20. κ*=0.20 (PROD-1 validated).
- μ(t): centroid tensor after t verified analyst decisions
- **κ* = 0.20** (PROD-1 validated, March 2026). Design estimate was 0.30 (near-floor).
- IKS = 0: centroid tensor has not moved from bootstrap baseline
- IKS = 100: centroid tensor has drifted the full normalization distance (saturated)

**Acceptance criterion (v5.5-R4):** IKS increases after every batch of verified analyst
decisions. IKS trend chart shows a non-flat line after 10 verified decisions. The score
and its weekly delta are displayed in Tab 2 header.

**Interpretation for a CISO:** "Day 1: IKS = 0. Day 30: IKS = 14. Day 90: IKS = 47."
The system has accumulated 47 units of firm-specific institutional knowledge that
did not exist at deployment. This is the single most important number for answering
Demo Question 2: "Show me it's getting smarter."

---

### Eq. T* — Category-Specific Auto-Approve Threshold Model (v5.5)

```
threshold*(c) = min{ θ ∈ [0, 1] : accuracy(θ, c) ≥ target_accuracy(c) }
```

- accuracy(θ, c): fraction of alerts in category c where the auto-approved action
  matches the oracle, measured on the 50-seed simulation pool at threshold θ
- target_accuracy(c): minimum acceptable accuracy for auto-approve in category c.
  Risk-stratified defaults:
  - insider_threat, lateral_movement: target = 0.92 (catastrophic miss cost)
  - credential_access, data_exfiltration: target = 0.88
  - cloud_infrastructure, threat_intel_match: target = 0.85

**PROD-4 validated (A=4):** 40%+ coverage at ≥85% per-category accuracy achieved.
The category-specific thresholds ship with v5.5.

---

## 4. Synthesis Extension (PROPOSAL — Eq. 4-synthesis)

**σ_max status:** σ_max = 0.034 (derived from FX-1-PROXY-REAL factor
distributions + L2 margin computation). The p10 of the empirical L2 margin distribution
at realistic AUAC. Previous design default was 1.0 (conservative placeholder, now
superseded).

---

## 5. Four Feedback Loops

| Loop | Updates | Signal | Rate | Temporal Role |
|---|---|---|---|---|
| **1: Score** | Decisions | f from graph | Every alert | Instant |
| **2: Learn** | μ (centroids) | Verified outcomes | Slow (η=0.05, decaying) | Past (months) |
| **3: Reward** | Learning rate | 20:1 asymmetry + count decay | Per outcome | Meta (permanent) |
| **4: Synthesize** (PROPOSAL) | σ (bias) | External + internal claims | Fast (daily) | Present (days) |

**Critical invariant — epistemic separation:**
Loop 2 centroid updates NEVER use σ. μ encodes what decision patterns LOOK LIKE
(experience from verified outcomes). σ encodes what actions are APPROPRIATE RIGHT
NOW (awareness from current intelligence). These are different epistemic categories.
Contaminating μ with σ would cause the system to "remember" a temporary campaign
as a permanent operational pattern. This is enforced in ProfileScorer.update()
which has no σ parameter.

**Layer 2 has two residents:**
- μ[c,a,:] ∈ [0,1]^d — operational centroids. Analogy: analyst's years of experience.
- σ[c,a] ∈ ℝ — synthesis bias. Analogy: this morning's threat brief. Fast to update,
  fast to decay. Never bleeds into the slow layer.

*"μ is what you've learned. σ is what you know right now. The good analyst uses both."*

#### Level 2 Formal Characterization: Conservative Contextual Bandit

AgentEvolver manages K prompt variants {v₁, ..., v_K} per (category, context)
combination. Context x_t = (alert_severity, analyst_experience_tier, time_period).
On each decision, AgentEvolver selects variant v_t, observes composite reward:
```
Eq. R-L2: r_t = w₁(phase) × accept_t + w₂(phase) × speed_t + w₃(phase) × outcome_t
```

Phase-gated weights (phase transitions by external milestones, not reward values):
- Phase 1 (Adoption, weeks 0-4): w₁=0.4, w₂=0.3, w₃=0.3
- Phase 2 (Calibration, weeks 4-12): w₁=0.2, w₂=0.2, w₃=0.6
- Phase 3 (Optimization, 12+ weeks): w₁=0.1, w₂=0.2, w₃=0.7

At phase transitions, inflate posterior variance by factor κ to allow
unlearning of prior-phase bias (Bayesian bridging with forgetting factor).

**Eq. GATE-L2 — Four-Condition Promotion Gate:**

A candidate variant v is promoted to default for context x only when ALL
four conditions pass:
```
(1) Superiority: P(μ_v(x) > μ_baseline(x) + Δ_min | data) > 1 − α
(2) Correctness floor: outcome_quality(v) ≥ outcome_quality(baseline)
(3) Conservation law: α(t) · q(t) · V(t) ≥ θ_min (see Eq. CL below)
(4) Variance stability: σ²_{r,v} ≤ σ²_{r,baseline} × (1 + δ)
```

Gate (1): one-sided Bayesian (Thompson Sampling preferred over frequentist
for rare categories). For frequentist fallback: N_gate ≈ (z_α + z_β)² × 2σ²_r / Δ²_min.
At σ_r=0.3, Δ_min=0.05, α=0.05, β=0.20: N_gate ≈ 445 per arm (one-sided).
Gate (2): prevents optimizing acceptance at the expense of decision quality.
Gate (3): ensures Level 2 optimization does not cannibalize Level 1's learning signal.
Gate (4): prevents deployment of variants with unpredictably volatile outcomes.

**Eq. CL — Conservation Law (Compounding Safety Constraint):**
```
α(t) × q(t) × V_verified(t) ≥ θ_min
where:
α(t) = analyst override rate (fraction disagreeing with system)
q(t) = override quality (fraction of overrides that are correct corrections)
V_verified(t) = verified decisions per day
θ_min = minimum informative signal rate for Level 1
```

**Connection to Level 1:** θ_min ≥ N_half / T_window per active (c,a) pair,
where N_half = ln(2)/η from Eq. CONV (§3.1). Level 2 must maintain enough
corrections for Level 1's convergence half-life. As graph matures and N_half
decreases (§10.1), θ_min also decreases — the conservation law becomes EASIER
to satisfy. This is the formal expression of two-level compounding.

**Automation complacency failure mode:**
Level 2 selects high-acceptance variant → α(t) decreases (fewer overrides)
→ Level 1 receives fewer correction signals → q(t) may decrease (remaining
overrides are from autopilot, not expertise) → α(t)·q(t)·V(t) drops below
θ_min → Level 1 improvement stalls → compounding fails. The conservation law
(Gate 3) prevents this by rejecting any variant that pushes the signal rate
below θ_min, regardless of acceptance improvement.

**N_half qualifier:** The convergence claim "N_half ≈ 14" requires
q̄≥0.70 AND σ≤0.157 (L2 kernel) or σ≤0.25 (DiagonalKernel). Below q̄=0.70:
confirm-only learning with ~2× timeline. Above noise ceiling: learning not
recommended (frozen scorer only).

**Conservation law q operational definition:** The invariant
α(t)·q(t)·V(t) ≥ θ_min uses q(t) operationalized as **rolling verified accuracy over
the last 400 decisions** (at 25% verify rate, ≈100 verified events per window).

Rationale (full derivation in §9):
- The v9.1 derivation established q as "per-decision quality" semantically, with no
  formal requirement that q be confidence specifically.
- UNI-DK-01 v5.3 established that DK confidence is miscalibrated at high NR (ECE 0.42
  at NR=5.0). If q were tied to confidence, the conservation invariant would operate
  on noisy inputs when DK is routed.
- Rolling verified accuracy directly measures decision quality, is calibration-
  independent, and strengthens the EU AI Act Article 14 oversight argument (accuracy
  is more defensible than confidence as evidence of effective oversight).
- SE on q at n=100 verified events, q≈0.85: ≈3.6pp. Tighter than any confidence-based
  window estimate.
- V in the invariant is a rolling aggregate and α is cumulative coverage; rolling-accuracy
  q sits naturally alongside them (it does not require α to be windowed — α is monotone).

This substitution does not change any v13 derivation structurally. Every step that
used q ≈ confidence either (a) used it as a semantic placeholder for "quality" (where
rolling accuracy is equivalent or stronger), or (b) needed calibrated confidence, which
rolling accuracy sidesteps entirely.

---

## 6. The Centroid Tensor

**Canonical SOC v6.0 dimensions:** μ ∈ ℝ^(6×4×6) = **144 values**

```
Categories (C = 6):
  0: credential_access
  1: threat_intel_match
  2: lateral_movement
  3: data_exfiltration
  4: insider_threat
  5: cloud_infrastructure

Actions (A = 4):
  0: escalate
  1: investigate
  2: suppress
  3: monitor
  NOTE: refer_to_analyst REMOVED as scorable action (v6.0 A=4 migration).
  Accessed via confidence gate (action routing) and ReferralRules R1-R7
  (referral routing — VETO mechanism, 72.7% DR, 12% FPR). Never in centroid
  tensor. Static accuracy improved 80.6→90.6% with A=4. Zero dangerous
  actions. 13pp structural gap confirmed by EXP-A4-DIAGONAL.

Factors (d = 6):
  0: travel_match
  1: asset_criticality
  2: threat_intel_enrichment
  3: time_anomaly
  4: pattern_history
  5: device_trust
```

**S2P domain (parallel):** μ ∈ ℝ^(5×5×8) = **200 values**
  5 categories × 5 actions × 8 domain-level risk scores.
  penalty_ratio=5.0 (vs SOC 20:1). SOC A=4 / S2P A=5 is intentional asymmetry.

Each μ[c,a,:] is a d-dimensional profile: "what does a credential_access alert that
should be escalated typically look like?" The centroids ARE the institutional judgment —
readable, auditable, and correctable by domain experts without touching code.

**Key prior (v5.0 corrected):** credential_access/escalate centroid — travel_match
set to 0.72 (was 0.30 in v4.5). Validated: high-travel vector → P(escalate) = 0.913 ✅

**Bootstrap calibration:** 1,200 synthetic decisions, σ=0.08, seed=42. Converged=True,
drift=0.0097. This is the warm-start baseline μ(0) for every deployment and the
reference point for IKS calculation.

**Synthesis tensor (PROPOSAL):** σ ∈ ℝ^(6×4) = **24 scalar values**.
"How should current intelligence shift action preferences for each category?"

---

## 7. Accuracy Numbers

### Two Accuracy Regimes — Never Mix Them

**Centroidal synthetic (EXP-C1, EXP-B1):** Tests the math in ideal conditions.
Oracle-generated factor vectors that perfectly align with centroids. Perfect routing.
These are the ARCHITECTURE VALIDATION numbers. Use to explain the mechanism.
Do NOT use as product claims.

**Realistic (50-seed validated):** Tests the product in realistic conditions.
Bernoulli oracle decisions (noisier), all FactorComputers with realistic noise,
full pipeline, realistic alert type distribution. These are the PRODUCT CLAIM numbers.
Use in customer communications, demos, and investor materials.

---

### Canonical Product Claim Numbers (50-seed validated, R50)

| Metric | Value | 95% CI | Condition |
|---|---|---|---|
| Static accuracy | 71.7% | [71.4%, 71.9%] | Combined realistic, no learning |
| Learning @ dec 1,000 | 78.9% | [78.1%, 79.6%] | Combined realistic, full learning |
| credential_access @ dec 1,000 | 68.0% | [66.7%, 69.1%] | Hardest category |
| Auto-approve accuracy (≥0.90) | 90.7% | [90.1%, 91.2%] | High-confidence suppress |
| Auto-approve coverage | 11.5% | ±0.70% | Alerts meeting ≥0.90 threshold |

**Frozen scorer baseline (A=4, March 2026):**

| Condition | Accuracy | Note |
|---|---|---|
| A=4 static (no learning) | 90.6% | A=4 migration improved from 80.6% (A=5) |
| A=5 static (historical) | 80.4% | SHIFT-2, noise=0, pre-A=4 migration |

**Learning lift (corrected update rule + asymmetric η):**

| Condition | Accuracy lift | Note |
|---|---|---|
| A=5, η_override=0.05 (old) | +2.7% | SHIFT-2, δ=0.10, warmup=1000 |
| A=4, η_override=0.01 (new) | +2.3pp to +3.7pp | Depends on noise ratio. HC: +3.7pp Diagonal. |

---

### DiagonalKernel Accuracy Numbers

**v14 note:** The DK accuracy claim is curve-based, not single-number. Two experiments
characterize different operating points on the same surface:
- **V-MV-KERNEL-HET (March 2026, 390 cells):** peak +13.2pp SOC on heterogeneous noise
  with variable mean-σ up to 0.30.
- **UNI-DK-01 v5.3 (April 2026, 1500 cells):** characterized +0pp to +7.67pp across
  NR=1.0 to NR=5.0 with fixed mean-σ=0.175.

Neither supersedes the other. The peak number is cited as "up to +13.2pp"; the v5.3
characterization is cited as "characterized at NR=5.0 mean-σ=0.175."

**Historical peak table (V-MV-KERNEL-HET) — unchanged, canonical for "up to" claims:**

| Metric | L2 | DiagonalKernel | Lift | Condition |
|---|---|---|---|---|
| SOC heterogeneous noise | 79.5% | 92.7% | **+13.2pp** | V-MV-KERNEL factorial, 72 cells, σ_level=0.30 |
| S2P heterogeneous noise | 42.2% | 49.0% | **+6.8pp** | V-MV-KERNEL factorial, 72 cells |
| SOC at σ_mean=0.22 (healthcare) | 61-64% | 83-85% | **+20-22pp** | High noise, hetero ratio 2-3× |
| Healthcare persona (V-HC-CONFIG) | 69.2%→69.5% (+0.3pp) | 70.2%→73.9% (+3.7pp) | **+3.4pp learning** | 15 seeds × 60 days |
| HC-C (extreme, ratio 4.6×) | -6.3pp (degrades) | +8.0pp (improves) | **+14.3pp swing** | L2 actively harmful |
| HC-A (ratio 3.2×) | -3.3pp | +6.4pp | **+9.6pp** | One very noisy factor |
| HC-B (ratio 1.9×) | +3.2pp | +5.5pp | **+2.3pp** | Moderate ratio |

**Corr(noise_ratio, diagonal_advantage) = 0.990** across 4 healthcare personas.
The advantage scales nearly perfectly with per-factor noise heterogeneity.

**Characterized surface table (UNI-DK-01 v5.3) — NEW v14:**

Methodology: true point-in-time decomposition. Cold-start measured via frozen-centroid
no-learning scorer (first 400 decisions). Asymptotic measured via 400-decision rolling
window at end of 5000-decision trajectory. Replaces cumulative-averaging decomposition
from Deliverable 1 (`v_mv_kernel_rerun_v1.json`) — that methodology is retracted.
See §3.3 for full methodology and theoretical background.

| NR | Cold-start gap | Learning gap | Asymptotic gap | Cold-start % of asymptotic | SE on asymptotic |
|---|---|---|---|---|---|
| 1.0 | 0.00pp | 0.00pp | **0.00pp** | — (mathematical identity) | 0.000pp |
| 1.5 | +0.53pp | +0.19pp | **+0.72pp** | 73.5% | 0.085pp |
| 2.0 | +1.50pp | +0.49pp | **+1.99pp** | 75.5% (peak) | 0.118pp |
| 3.0 | +3.09pp | +1.35pp | **+4.43pp** | 69.6% | 0.156pp |
| 5.0 | +4.18pp | +3.49pp | **+7.67pp** | 54.5% | 0.191pp |

1500 cells total (5 NR × 5 q̄ × 30 seeds × 2 kernels), 150 paired cells per NR.

Key findings from the surface:
1. NR=1.0 gap is exactly 0.00pp with zero variance across 150 cells — the DK-collapses-to-L2
   mathematical identity is empirically confirmed at scale.
2. Cold-start is the larger contributor at every NR, but its fraction peaks at NR=2.0
   (75.5%) and declines to 54.5% at NR=5.0 as learning grows faster than cold-start at
   extreme heterogeneity.
3. Learning contribution is positive at every NR: +0.19pp to +3.49pp. The previously
   reported "negative learning at low NR" (from cumulative-averaging v4.2 measurement)
   is **retracted as a measurement artifact**.
4. q̄-invariance of cold-start confirmed: max q̄-std = 0.285pp (was 1.22pp under v4.2
   cumulative measurement that failed this check).

### DiagonalKernel Calibration Properties

**DK's accuracy advantage does NOT translate to calibrated confidence.** Expected
Calibration Error at τ=0.1:

| NR | L2 ECE | DK ECE | Ratio |
|---|---|---|---|
| 1.0 | 0.055 | 0.055 | 1.0× |
| 1.5 | 0.053 | 0.148 | 2.8× |
| 2.0 | 0.051 | 0.223 | 4.4× |
| 3.0 | 0.046 | 0.325 | 7.0× |
| 5.0 | 0.041 | 0.420 | 10.4× |

L2 is well-calibrated across the range. DK is severely miscalibrated at high NR.
Mechanism: W = diag(1/σ²) normalization concentrates weight on low-σ factors. At NR=5.0,
W = [1.00, 0.31, 0.15, 0.09, 0.06, 0.04] — effective dimensionality ~3 of 6. Reduced
effective dimensionality sharpens the softmax, producing over-confident predictions
on the decisive subset.

This is a fundamental property of inverse-variance weighting, not an implementation
defect. **Consequence: production touchpoints that consume raw DK confidence require
architectural response** — see §3.3 downstream consequences table, §9 S6 auto-pause
update, and §16 constraints.

---

### Product Boundaries (Phase 1 Persona Sweeps + Factorial)

| Dimension | Boundary (L2) | Boundary (Diagonal) | Evidence |
|---|---|---|---|
| Factor noise ceiling | σ≤0.105 GREEN, ≤0.157 AMBER | σ≤0.157 GREEN, ≤0.25 AMBER | 1D + V-MV-KERNEL |
| Alert volume | V≥30 viable | Same | 1A sweep (5 personas) |
| Team quality | q̄≥0.70 for full lift | Same (η_override handles low quality) | 1C sweep (5 personas) |
| Team size (Level 2) | A/B needs ≥8 analysts | Same | 1B sweep (5 personas) |
| Graph enrichment | +7 to +13pp from noise reduction | Same | 2G sweep (2 personas) |
| Correlated error | Conservation detects in 5 days | Same | 2D sweep (2 personas) |
| Recovery | ≤3 days at all tested volumes | Same | V-CL-RECOVER (2 personas) |
| Healthcare | Frozen scorer + remediation first | **Learning from Day 1** | V-HC-CONFIG diagonal |
| Kernel selection | — | noise_ratio > 1.5 → Diagonal | Selector fixes (4/4 correct) + UNI-DK-01 v5.3 E3 (100% rule-correct) |
| Selector stabilization | — | **max(1000, 20×V×α) decisions** (corrected from earlier "~250 decisions" estimate) | V-GATE-STABILITY (N=1000 confirmed) |

---

### Architecture Validation Numbers (centroidal synthetic — qualify always)

| Metric | Value | Experiment | Condition Qualifier |
|---|---|---|---|
| L2 zero-learning accuracy | 97.89% | EXP-C1 | Centroidal synthetic, correct routing |
| L2 with-learning accuracy | 98.2% | EXP-B1 | Centroidal synthetic, warm-start |
| Calibration ECE at τ=0.1 | 0.036 | V3B | Centroidal synthetic |

When stating 97.89% or 98.2%: always append "validated on centroidal synthetic data
with oracle routing. Real-data routing accuracy pending GATE-R." Omitting this
qualifier is a forbidden claim (see §13).

---

### The Consistency Claim (Unconditional — No Experiments Required)

> **Every analyst on your team receives the same starting recommendation, from the
> same reasoning, every time — regardless of which analyst is reviewing the alert,
> what time of day it is, or how long they have been on shift.**

This claim requires no experiments, no gate results, and no qualifications. It is
true at v5.0 today and will remain true at all future versions.

---

### The Accuracy Waterfall (Updated for A=4)

```
Random baseline ..................... 25.0%   (1/4 actions — n_act = 4)
Shared W + Hebbian (EXP-A) ......... 49.3%   original architecture
Per-category W (EXP-A2) ............ 51.6%   attempted fix
Dot product centroid (EXP-C1) ...... 61.0%   right model, wrong kernel
Cosine centroid (EXP-C1) ........... 96.4%   magnitude confounding removed
L2 centroid zero-shot (EXP-C1) ..... 97.89%  ← ARCHITECTURE (centroidal)
L2 + learning (EXP-B1) ............. 98.2%   operational refinement (centroidal)
Frozen μ₀ baseline (A=4) ........... 90.6%   ← EXPERT PRIOR (A=4, noise=0)
Diagonal μ₀ + learning (HC) ........ 73.9%   ← DiagonalKernel on healthcare
Realistic static ................... 71.7%   ← PRODUCT CLAIM (50-seed)
Realistic @ 1,000 decisions ........ 78.9%   ← PRODUCT CLAIM (50-seed)
```

---

## 8. Key Experimental Results

| Exp | Question | Result | Status |
|---|---|---|---|
| EXP-5 | GT-aligned oracle works? | 79.65% (was 40–44% Bernoulli) | ✅ PASS |
| EXP-A | Gating Matrix G helps? | **FALSIFIED** (+0.01pp, 4 variants) | ✅ FALSIFIED |
| EXP-C1 | Profile centroids work? | **97.89% L2** (settles architecture) | ✅ PASS |
| EXP-B1 | Learning improves centroids? | 98.2% warm, 90.7% cold, robust to 30% noise | ✅ PASS |
| EXP-D1 | Cross-category transfer? | Marginal (config wins 2–14pp) | ✅ DONE |
| EXP-D2 | Factor interactions? | None significant (75 pairs) | ✅ DONE |
| EXP-E1 | Which kernel? | L2 wins 2/3, pluggable for mixed-scale | ✅ DONE |
| EXP-E2 | Scales? | 99.9% at 20×10×20 | ✅ PASS |
| GATE-G | Gating obsolete? | ✅ PASSED — ProfileScorer is THE scorer | ✅ PASS |
| GATE-OP | λ=0.5 operative? | ✅ PASSED — p=0.0008 at centroidal AUAC≈0.97 | ✅ PASS |
| V1A | Scaling exponent? | b=2.11 ± 0.03, R²=0.9999 (sim). **R² this clean = generator-fit, not empirical validation; EXP-G1 is the validation path. [v18]** | ✅ VALIDATED (simulation only) |
| V1B | Norm explosion? | 2.9M× without LayerNorm → required | ✅ VALIDATED |
| V2 | Push stability? | Centroid escape → [0,1] clipping required | ✅ VALIDATED |
| V3A | Beats ML baselines? | L2 94.78% vs XGBoost 92.24% vs RF 92.93% | ✅ VALIDATED |
| V3B | Calibration? | ECE=0.036 at τ=0.1 (ECE=0.19 at τ=0.25) | ✅ VALIDATED |
| SHIFT-2 | Update rule corrected? | +2.7% lift (was -9.0% pre-fix). Dual push/pull. | ✅ PASS |
| DISC-1 | Composite discriminant? | 70.4% coverage vs 62.6% confidence-alone (+7.8pp) | ✅ PASS |
| **V-MV-KERNEL** | **DiagonalKernel vs L2?** | **+13.2pp SOC, +6.8pp S2P on heterogeneous noise (peak, variable mean-σ)** | **✅ PASS** |
| **V-HC-CONFIG** | **Diagonal rescues healthcare?** | **+3.7pp (Diagonal) vs +0.3pp (L2) at σ=0.22** | **✅ PASS** |
| **V-HC-SHRINKAGE** | **Off-diagonal helps?** | **<1pp gap. Explanation A confirmed.** | **✅ DONE** |
| **B5B-PROXY** | **Realistic analyst quality?** | **13-27pp degradation → P0 fix (η_override=0.01)** | **✅ PASS** |
| **Phase 1 sweeps** | **Product boundaries?** | **σ≤0.157(L2)/0.25(Diag), V≥30, q̄≥0.70, B-A≥8** | **✅ PASS** |
| **HC-scaling** | **Noise ratio predicts advantage?** | **r=0.990 across 4 personas. Monotonic.** | **✅ PASS** |
| **KernelSelector** | **Auto-select correct kernel?** | **4/4 correct. Rolling 100-window. max(1000,20×V×α) decisions.** | **✅ PASS** |
| **EXP-A4-DIAGONAL** | **A=4 vs A=5 under Diagonal?** | **13pp structural gap. Kernel-independent. A=4 confirmed.** | **✅ PASS** |
| **EXP-REFER-COVERAGE** | **What fraction of referrals are rule-expressible?** | **72.7% rule-expressible. 20.7% emergent. 6.6% undetectable.** | **✅ DONE** |
| **EXP-REFER-LAYERED** | **Which referral layers ship?** | **Rules: 72.7% DR, 12% FPR. Confidence gate: 14% precision (harmful). Override learning: +1.1pp at 1,500 decisions (premature).** | **✅ DONE** |
| **UNI-DK-01 v5.3** | **DK characterization surface + calibration properties?** | **+7.67pp at NR=5.0 (asymptotic, mean-σ=0.175 fixed). Cold-start dominates 54.5–75.5% across NR. D1-D4 all PASS. D5 dropped (tautological in v4.2 design). DK ECE 0.42 at NR=5.0 vs L2 ECE 0.04 — calibration finding.** | **✅ PASS** |

### Experiment A1 — Safety-Layer Characterization (Sep 2026)

**Design:** 3 gate configs (G-ABS, G-REL, G-BOTH) × 2 regimes (cold-start,
steady-state) × 3 threat conditions (clean, sustained-poison, sudden-drop)
× 5 copilots × 3 seeds = 90 cells per round.

**A1-R1 result:** NOT ESTABLISHED. G-BOTH (two layers) does not cover sudden
drops — the relative trigger averages a 15pp drop to <2pp across the
400-decision window. V_clear ≈ 3 (absolute floor trivially short).

**A1-R2 result:** ESTABLISHED. Extended to 5 gate configs (added G-RATE
and G-THREE). G-THREE (three layers) covers all applicable threat cells.
G-RATE detects 86.7% of sudden drops at 0.87% false-pause (m_rate=0.85×,
W_short=20, lag 19.67 decisions). Threshold sensitivity: 0.85× is the
operating point (0.87% fp vs 7.67% at 0.90×). Deterministic 2-rebuild
confirmed.

- **Signal tier:** T-real (floors) + T-sim (injected threats).
- **Maturity tier:** Tier 2.

**Consequence:** §9 safety architecture restructured from two-layer to
three-layer. G-RATE (W_short, m_rate) added to state objects in
ci_math_engine_architecture_v6.

**JM per-threat-model conservation (v26, C3).** The JM redesign harness measured the
calibrated conservation gate across four threat types (40 deployments, 5,000 bootstrap
resamples): the gate detected sustained corruption, gradual drift, and sudden change in
**100% of trials with 0% clean false positives**; sparse 10% adversarial injection was
detected in **57%, defining the measured sensitivity boundary.**

**A1 reconciliation:** The A1 three-layer gate (A1-R2, above) and the JM conservation
gate (E-JM-4) measure the same mechanism at different operating points. A1-R2 used
production-fixed parameters (W_short=20, m_rate=0.85, 7.5% FPR on Bernoulli streams);
E-JM-4 used a per-threat-model sweep with calibrated thresholds (0% FPR). They do not
contradict — A1-R2 defines *production false-pause rate*, E-JM-4 defines *detection
capability per threat model*. Signal tier: T-real-sim (JM apparatus).

| Threat model | Detection rate | FPR | Source |
|---|---|---|---|
| Sustained corruption | 100% | 0% | JM apparatus E-JM-4 |
| Gradual drift | 100% | 0% | JM apparatus E-JM-4 |
| Sudden change | 100% | 0% | JM apparatus E-JM-4 |
| Sparse adversarial (10%) | 57% | 0% | JM apparatus E-JM-4 |
| Sudden drops (production params) | 86.7% | 0.87% | A1-R2 (G-RATE) |

**v14 deprecation:** Deliverable 1 decomposition tables (cold-start 76% / learning
reconstruction) in `v_mv_kernel_summary_v2.md` are **superseded** by UNI-DK-01 v5.3.
The superseded numbers used cumulative-averaging methodology now known to produce
measurement artifacts. Retained for historical context only; do NOT cite forward.
`v_mv_kernel_rerun_v1.json` and `v_mv_kernel_rerun_v3.ipynb` archived.

---

### Synthesis and Validation Experiments (PLANNED — unchanged from v9.1)

| Exp | Question | Gate | AUAC Condition |
|---|---|---|---|
| EXP-S1 | Does σ improve accuracy? | GATE-M: ≥3pp, p<0.0083, ECE ≤+0.02 | Centroidal |
| EXP-S2 | Poisoning resilience? | GATE-M: ≤2pp at 20% bad claims | **Both: centroidal + realistic** |
| EXP-S3 | σ contaminates μ? | GATE-M: ≤5% centroid divergence | Centroidal |
| EXP-S4 | λ sensitivity? | GATE-M: plateau ≥0.05 wide | Centroidal |
| EXP-S5a | Real CISA KEV → σ? | GATE-D-early: ≥3 σ cells updated in <60s | Real data |
| EXP-S5b | Work artifact → claims? | GATE-D-early: LLM F1 ≥ 0.70 | Real data |
| EXP-S5 | Full pipeline? | GATE-D: end-to-end latency <200ms P95 | Real data + v6.0 |
| EXP-S6 | INTSUM-quality briefing? | GATE-D: ≥80% claim coverage, LLM judge | Real data |
| EXP-S7 | Ask-the-Graph improvement? | GATE-D: ≥10/15 correct (3 conditions) | v5.0 baseline |
| EXP-S8 | Real synthesis → real decisions? | GATE-V: ≥3pp treatment, ≤1pp irrelevant degradation | Real deployment |
| ~~FX-1-PROXY-REAL~~ ✅ | Real factor distributions | KL 1.88–2.58. σ_max=0.034 derived. | ✅ Complete |
| PROD-1 ✅ | IKS κ* calibration? | κ*=0.20. 100% of seeds in [15,40] range. | ✅ Complete |
| PROD-3 ✅ | Shadow mode baseline? | θ: 0.744–0.809 per category. | ✅ Complete |
| PROD-4 ✅ | Per-category threshold*? | 40%+ coverage at ≥85% accuracy (A=4). | ✅ Complete |

---

## 9. Safety Architecture

### Synthesis Safety Layers

| Layer | Mechanism | Prevents |
|---|---|---|
| S1 | Extraction confidence gate (≥0.80) | Low-quality claims affecting σ |
| S2 | Source trust weighting (tier × confidence) | Untrusted sources dominating |
| S3 | Magnitude clipping σ ∈ [−σ_max, +σ_max] | Any combination of claims overriding μ |
| S4 | Human confirmation for high-impact Δσ | Misinterpreted or manipulated claims |
| S5 | Full rollback audit trail (claim provenance) | Damage assessment and reversal |
| **S6** | **AMBER auto-pause: rolling verified accuracy drops → freeze learning** | **Detection-without-response gap** |
| **S6a** | **G-RATE short-window rate detector: accuracy of last W_short=20 decisions below m_rate=0.85× long baseline → AMBER** | **Sudden drops in steady-state that the long-window relative trigger averages away (A1-R1 measured the gap; A1-R2 measured the fix: 86.7% detection at 0.87% false-pause, lag 19.67 decisions)** |
| **S7** | **Asymmetric η: η_override=0.01 (5× attenuation on override path)** | **Centroid corruption from low-quality overrides** |
| **S8** | **DiagonalKernel: down-weight noisy factors via W=diag(1/σ²)** | **Noisy factors corrupting scoring and learning** |
| **S9** | **ReferralRules R1-R7: policy-based VETO after composite gate** | **Alerts needing human review that confidence gate misses (72.7% DR, 12% FPR)** |

**S6 signal-source update (v14):** Auto-pause previously specified confidence-threshold
trigger. With DK available as a deployment-specific option (L2 is the production default) and DK confidence miscalibrated at high NR
(ECE 0.42 at NR=5.0, see §3.3), confidence-based triggering is unreliable for
DK-routed deployments.

v14 changes auto-pause to trigger on **rolling verified accuracy crossing below
deployment-specific threshold** — same signal that powers the conservation-law q.
Implementation:
- Signal: rolling accuracy over last 400 decisions (≈100 verified events at 25% rate)
- Trigger condition: accuracy drops below (baseline_accuracy × 0.9) or below absolute
  floor (0.70 for safety-critical categories, 0.60 general)
- State transition: AUTO zone paused. Subsequent decisions routed to human review
  instead of auto-acted. Does NOT filter per-decision — it's a system-state change.
- Resume condition: rolling accuracy recovers above threshold for ≥100 consecutive
  decisions. Returns to AUTO.

This is architecturally cleaner than confidence-based auto-pause for three reasons:
1. Directly measures accuracy degradation (what we actually care about)
2. Robust across kernel choice (no calibration dependency)
3. Same signal as q in the conservation invariant — single monitoring pipeline

**Per-decision uncertainty gating** (a separate question — not auto-pause): if
deployments need per-decision uncertainty filters within the AUTO zone, use softmax
entropy or confidence-gap thresholds. Entropy captures decisiveness without requiring
calibrated probabilities. See gae_design for the per-decision triage ranking spec.

**S9 architectural guarantee:** ReferralRules insert AFTER the composite
scoring gate, BEFORE response build. ProfileScorer scoring (Stage 1) accuracy is
unaffected by construction (|accuracy change| = 0.0pp). The referral decision is independent of and cannot
contaminate the scoring decision. Rules R1-R7 are deterministic pure functions with
safe defaults (missing context → rule doesn't fire → false negative, not false positive).
Override learning (v6.5+) activates only when ≥50 positive examples accumulate in the
override buffer — data-gated, not calendar-gated.

**σ_max status:** σ_max = 0.034. Derived from FX-1-PROXY-REAL factor
distributions + L2 margin computation on characterized distributions. The p10 of the
empirical L2 margin distribution at realistic AUAC. Previous design default was 1.0
(conservative placeholder, now superseded).

**Architectural guarantee:** At σ_max=0.034 and λ=0.5 (operative), max synthesis
influence = 0.017 distance units. Typical L2 distances = 0.5–2.0. Experience (μ) always
dominates awareness (σ). EXP-S2-REPRO confirmed poisoning resilience holds (0.15pp max).

### Verification Safety Architecture

**Asymmetric learning rates (P0 fix):** The override path (analyst changes
system recommendation) carries noise from analyst errors. At realistic analyst quality
(q̄=0.60-0.70), this noise caused 13-27pp centroid degradation with symmetric η.
η_override=0.01 attenuates the override signal by 5× relative to confirms:
  - Confirm path: η_confirm=0.05 (clean signal → full learning rate)
  - Override path: η_override=0.01 (noisy signal → attenuated rate)

Validated across 24 personas (6 sweeps). At q̄=0.57 (worst tested quality):
+0.5pp with η_override=0.01 (no degradation). Without: -9pp.

**Conservation-law q operational definition:** q(t) in α(t)·q(t)·V(t) ≥ θ_min
is operationalized as rolling verified accuracy over the last 400 decisions.

Formal definition:
```
q(t) = (1/N_v(t)) · Σᵢ∈W(t) 𝟙[prediction_i = verified_action_i]

where:
  W(t) = last 400 decisions at time t
  N_v(t) = number of verified decisions in W(t) (≈100 at 25% verify rate)
  𝟙[·] = indicator of prediction-action match on verified events only
```

Properties:
- Standard sampling estimator for underlying accuracy rate across the window
- Population estimate: q(t) estimates E[correct | decision ∈ W(t)] over all decisions
  in the window (verified and unverified alike), assuming verification is uniformly
  sampled (true by design)
- SE on q at n≈100, p≈0.85: ≈3.6pp (tighter than any confidence-based window estimate)
- Calibration-independent: works for both L2 and DK without calibration infrastructure
- Sits naturally alongside V (rolling) and α (cumulative coverage) in the invariant

**Why not per-decision confidence:**
- DK's confidence is miscalibrated at high NR (ECE 0.42 at NR=5.0, §3.3)
- Confidence-based q would operate on noisy inputs when DK is routed
- Confidence is an estimate of quality; verified accuracy IS quality (on the verified
  subsample) — more direct operationalization
- Strengthens EU AI Act Article 14 oversight claim (accuracy is more defensible)

**Why v13 derivation remains valid under this substitution:** The v13 derivation
established q as "per-decision quality" semantically. It did not require q ≈ confidence
specifically. Every derivation step that uses q operates on its semantic meaning as
a quality measurement, which rolling verified accuracy satisfies equivalently or more
directly than confidence. No re-derivation is required. See §12 for closure of the
audit question.

**AMBER auto-pause:** When ConservationMonitor signals AMBER or RED
(α·q·V drops below 0.7× baseline or absolute floor θ_min=23.53/(α×V)),
learning freezes automatically. No centroid updates until GREEN resumes. Prevents
continued corruption during detected degradation episodes. Three-judge consensus.
Trigger signal for AMBER transition: same rolling verified accuracy that defines q.
 In steady state the *relative* trigger (0.7× rolling baseline)
is the operative protector; the *absolute* floor θ_min is vestigial once volume is
moderate (see θ_min provenance note below).

**Three-layer gate update (A1-R1/R2):** Conservation uses three layers (G-ABS absolute floor,
G-REL relative trigger, G-RATE short-window rate detector), all required. G-ABS protects cold start;
G-REL protects sustained drift; G-RATE protects sudden steady-state drops that a long window averages away.
The G-RATE parameters are `W_short=20` and `m_rate=0.85×`; the G-REL multiplier is `m_rel=0.7×`.

**θ_min provenance:** θ_min = 23.53/(α·V) uses an empirically calibrated
constant (23.53), not a first-principles derivation. It was tuned from the observed
half-convergence volume (N_half ≈ 14 at η_confirm=0.05) so that the autonomous-scope
gate stays closed during cold start. Equivalently the invariant is **α²·q·V² ≥ 23.53**.
The gate is binding only for the first few verified decisions: it goes non-binding beyond
V_clear ≈ 3 (range 3.0–3.3 across all five copilots, A1-R2 measured). The cold-start protection
window is smaller than previously estimated. It also functions as an accuracy-degradation auto-pause
(via the 0.7× relative trigger), not a continuously binding steady-state bound. The earlier
V≈8/V≈16/V≈32 coverage-specific estimates are superseded by the A1-R2 measurement. Beyond those
historical volumes it is satisfied by a wide margin and functions as a cold-start interlock plus
an accuracy-degradation auto-pause
(via the 0.7× relative trigger), **not** a continuously binding steady-state bound. The
two prior derivations — `N_half × η × V_min` (this document, v12) and `η × N_half² /
T_max_days` (ci_blog) — are mutually inconsistent (neither cleanly yields 23.53 at
N_half≈14) and are both retired. A principled first-principles derivation is open work.

**Count decay:** η_eff decreases with n[c,a]. Early decisions (low n) produce large
centroid moves. Late decisions (high n) produce small refinements. A mature category
profile (high n) is resistant to individual noisy feedback events.

**N3 endogenous loop (KNOWN RISK — no intervention point designed):**
Calibration error → biased verification selection → learning from biased data →
worse calibration → repeat. No intervention point has been designed for this loop.
Mitigation: shadow mode data from first deployment allows measurement of whether
verification is systematically biased. Disclosed in EU AI Act Article 9 risk log
and shadow mode deployment documentation. Full characterization requires EXP-S8
with real analyst decisions.

### §9.1 — Defense-in-Depth Safety Architecture

Safety is three layers, not one mechanism. Shrinkage alone is a mathematical guardrail (0/21 at α=0.5 is engineering signal — rule of three gives ≤14% upper bound at 95% CI, NOT a statistical proof).

```
LAYER 1: James-Stein Shrinkage (mathematical guardrail)
  w̃ = α × w_DK + (1-α). Interpolated estimator provably better than either
  extreme for p ≥ 3 (Stein 1956). SOC: p=144. S2P: p=200.
  Empirical: α=0.5 → 0/21 below centroid (RATE-9). α=1.0 → 3/21 (14%).

LAYER 2: Promotion Gate (operational guardrail)
  No DK weights deploy without holdout non-inferiority (Eq. PROMOTION-GATE, §3.5).
  Catches edge cases that shrinkage misses.

LAYER 3: Rollback + Conservation Law (recovery and monitoring)
  Instant revert to any prior promoted state via BatchHistory.
  Conservation α·q·V ≥ θ_min monitors overall health. AMBER auto-pause.
  Also: set α=0 → pure centroid, instant, no data loss.
```

**NOT the argument:** "Shrinkage guarantees safety."
**The argument:** "Defense in depth with mathematical, operational, and recovery layers."

S10 (NEW v15): Promotion gate — holdout non-inferiority before DK weight deployment.

---

## 10. Scaling Properties

**Domain scaling — information-gain compounding [TERM FIXED v18]:** Information gain
I(n) ~ O(n^b) where b=2.11 ± 0.03 (V1A, **T-sim** — simulation-only; R² this clean reflects generator-fit, not empirical validation). Super-quadratic *in this model*:
adding the 10th domain provides more than 10× the information gain of the 1st. This is
the theoretical basis for the **information-gain compounding** claim — distinct from
**operational compounding** (deployment quality×scope increasing returns, c≈1.14, a
bounded onboarding transient; see JM paper E-JM-6) — and distinct from **cumulative
advantage** (c=1.387, JM apparatus; see new §10.2 below). Bare "compounding" is not used (D2).
**Condition:** b=2.11 is validated in simulation only and must not be stated as an
empirical result without EXP-G1. The R²=0.9999 (V1A) reflects fit to a generator that
already assumes a power law — treat it as characterization of the model, not confirmation
of the world. EXP-G1 (planned, real multi-domain data) is the validation path; until it
returns, neither compounding term may be asserted as production-validated.

**JM measured upgrade (v26, C2).** The JM redesign harness (40 deployments, 5,000
bootstrap resamples) measured the discovery surface directly: **SDK cross-domain discoveries
scaled as α_d = 2.150, 95% CI [2.030, 2.299], across domains; and β_d = 2.622,
95% CI [2.436, 2.964], across sequential evidence sweeps (measured, JM apparatus).** The
VLD simulation b=2.11 (V1A, T-sim) is the mechanism evidence; the JM measurement is the
measured upgrade. Signal tier: T-sim (V1A) upgraded to T-real-sim (JM apparatus) for
discovery scaling. Both are cited; JM supersedes for magnitude claims.

**Category scaling:** 99.9% accuracy at 20 categories × 10 actions × 20 factors
(EXP-E2, centroidal synthetic). No degradation with tensor dimensionality.

**Temporal compounding (operational):** Cold start 52% → 90.7% accuracy at 1,000 decisions (EXP-B1,
centroidal). Warm start 97.89% at decision 1 (EXP-C1). The gap between warm and cold
IS the quantified value of institutional judgment encoded in the centroid tensor.

**Kernel compounding (operational):** The distance metric itself improves
as deployment matures. Day 1: L2 (before per-factor σ measured). Day 30+: DiagonalKernel
with weights calibrated from P28 deployment qualification. The kernel W=diag(1/σ²) is
firm-specific — a competitor who copies the code starts with W=I.

UNI-DK-01 v5.3 characterized the DK scaling surface: at controlled NR=5.0 mean-σ=0.175,
asymptotic DK advantage is +7.67pp; at variable mean-σ up to 0.30 (V-MV-KERNEL-HET),
peak is +13.2pp. The advantage scales with both mean noise level AND noise heterogeneity.

**CovarianceEstimator:** Online covariance collection with Ledoit-Wolf
shrinkage. half_life=300 decisions (≈90 days at V=100). Collects per-factor σ (used
by DiagonalKernel) and full correlation matrix ρ (logged, not used for scoring at v6.0).
Research asset for v7.0 shrinkage investigation if high-ρ domains emerge.

---

### §10.1 — Graph-Dependent Convergence

**Eq. σ²_G — Graph-Dependent Factor Noise:**
```
σ²_{f,j}(G) ≈ σ²_{f,j,base} / N_eff,j(G)
where N_eff,j = N_sources,j / (1 + ρ_j(N_sources,j − 1))
```

- N_sources,j(G): number of data sources contributing to factor j at graph
  maturity G
- ρ_j: average cross-source correlation for factor j
- [Gemini correction]: at ρ=0.8, adding a second SIEM reduces variance by
  ~11%, not 50%. Security sources are highly correlated (often different
  views of the same telemetry).

**Three mechanisms of graph-dependent convergence:**

| Mechanism | How Graph Maturity Helps | Effect on N_converge |
|---|---|---|
| Multi-source noise averaging | More corroborating sources → lower σ²_f (ρ-adjusted) | Steady-state neighborhood shrinks → lower ε floor |
| Entity resolution | Cross-source identity linking → richer per-alert context | ‖e_0‖ decreases (better initial alignment) |
| ThreatIndicator accumulation | Persistent IOC memory → enriched threat_intel factor | σ²_{threat_intel} decreases over time |

**Graph-dependent convergence time:**
N_converge(G) = ln(‖e_0(G)‖ / √(η·tr(Σ_f(G))/(2−η))) / η

Both ‖e_0(G)‖ (initial mismatch) and tr(Σ_f(G)) (factor noise) decrease
with graph maturity. N_converge decreases → the system calibrates faster
the richer the graph becomes.

**Connection to temporal compounding exponent γ:**
If N_converge(G(t)) decreases with time t (because graph richness G(t) grows),
then effective learning speed increases with time — which is the mechanism
for γ>1 in the moat equation I(n,t) ~ O(n^b × t^γ). [Gemini: "The
mapping is legitimate. γ>1 is the result; Bridge B is the engine."]
This provides mechanism-level grounding for EXP-G1. Whether γ>1 holds
empirically is still PENDING EXP-G1 — the mechanism argument does not
substitute for measurement.

*v26 note:* The domain exponent b=2.11 now has a JM measured counterpart α_d = 2.150
(§10.2). The γ in this equation is the re-convergence ratio (§3.2), DISTINCT from the
cumulative advantage c = 1.387 and discovery time-scaling β_d = 2.622. See §10.2 exponent
family table.

**Secondary virtuous loop [Gemini finding]:** As Level 1 improves → alert
volume for analysts drops → analyst fatigue decreases → override quality
q(t) increases → Level 1 gets better correction signal → Level 1 improves
further. This is a third compounding mechanism beyond Levels 1 and 2.

**Three regimes of graph enrichment:**

| Regime | When | N_converge Effect |
|---|---|---|
| Early (sources connecting) | Weeks 1-4 | Drops rapidly |
| Mid (ThreatIndicator accumulating) | Months 1-6 | Drops steadily |
| Mature (graph saturating) | 6+ months | Flattens — diminishing returns |

**Experiment:** B-1 Phase B: simulate graph maturity levels G₁ (single
source) through G₄ (2 SIEMs + entity resolution + 400 ThreatIndicators +
1000 prior decisions) with ρ-adjusted noise. Measure N_converge(G)/N_converge(G₁).
Success: N_converge(G₄) < N_converge(G₁) by ≥30%.

Phase C (temporal test): on 5,000-decision simulation, plot per-window
N_converge. If rate increases with graph accumulation → mechanism-level
evidence for γ>1.

> **v13 NOTE:** The connection to γ is now formalized in §3.2. Graph enrichment
> (W2 edges, PatternHistory) increases the effective learning signal s̄ in Phase 2,
> providing Strengthening Lemma A for the re-convergence theorem. The γ > 1 condition
> (Eq. GAMMA-THEOREM) can be satisfied by geometry alone (ε_firm > ε_firm★) when
> graph enrichment is absent; when enrichment is present, the condition is met at
> smaller ε_firm values. See §3.2 for the full theorem and conditions.

---

### §10.2 — Cumulative Advantage (JM Apparatus, v26)

**Cumulative advantage — measured, not modeled.** Against a decision-0 frozen twin on
identical scenarios, cumulative K-learning advantage scaled as **c = 1.387,
95% CI [1.308, 1.477]** (measured, JM apparatus, 40 deployments, 5,000 bootstrap
resamples) — super-linear, the interval excluding 1. The advantage curve is unbounded
(the frozen twin never improves); accuracy, by contrast, saturates logistically
(c_acc = 0.643, sub-linear by construction for any bounded quantity). K-learning improved
bounded decision quality by **+21.96 percentage points** over a frozen twin.

**Signal tier:** T-real-sim (JM apparatus). The VLD compounding curves (§10 temporal,
kernel, +3–21 routing pts) establish mechanism; this measurement establishes magnitude.

**Exponent family (v26, canonical):**

| Symbol | Quantity | Value | 95% CI | Source | Signal |
|---|---|---|---|---|---|
| c | Cumulative advantage | 1.387 | [1.308, 1.477] | JM apparatus E-JM-6 | T-real-sim |
| α_d | Discovery scaling (domain) | 2.150 | [2.030, 2.299] | JM apparatus E-JM-6 | T-real-sim |
| β_d | Discovery scaling (time) | 2.622 | [2.436, 2.964] | JM apparatus E-JM-6 | T-real-sim |
| c_acc | Bounded accuracy | 0.643 | — | JM apparatus E-JM-6 | T-real-sim |
| b | Info-gain compounding (sim) | 2.11 | ±0.03 | V1A simulation | T-sim |
| c_op | Operational compounding | ≈1.14 | — | JM paper E-JM-6 (bounded transient) | T-real-sim |
| γ (re-convergence) | Recovery speed ratio N₁/N₂ | ≈1.2 (L2) | — | Sim (§3.2) | T-arch + T-sim |

**Disambiguation:** γ is the re-convergence ratio only (§3.2, Gate GAMMA). Cumulative
advantage uses c; discovery time-scaling uses β_d. The prior informal use of γ as a
temporal compounding exponent is retired (v6 results note).

**Condition:** c = 1.387 is T-real-sim (40 synthetic deployments). T-pilot requires
6–12 months of operational data. The +21.96pp gain is bounded-accuracy improvement.
See Gate JM-APPARATUS (§13) for claims rules and forbidden statements.

---

## 11. Gap Analysis — Five Customer Problems vs Current Architecture

**Problem 3 update:** Auto-approve coverage target 40%+ achieved
at v5.5 with A=4 migration + PROD-4 per-category thresholds. The three-tier
dispatch (auto-approve / investigate / full review) ships at v5.5 with A=4
actions (escalate, investigate, suppress, monitor). Referral routing handled
by ReferralRules R1-R7 (policy-based VETO, independent of scoring). The referral
question is solved at the architecture level: scoring determines WHAT action to take
(4 centroids), rules determine WHO should see it (7 policy rules). These are
orthogonal concerns — an alert can be high-confidence suppress AND flagged for
referral (e.g., executive account during M&A).

**Problem 6 (NEW v11): The Referral Problem.** "When should a human see this alert,
regardless of system confidence?" The confidence gate catches "I don't know."
ReferralRules R1-R7 catch "I know this is technically fine, but organizational
context says a human should see it." EXP-REFER-LAYERED validated: rules deliver
72.7% detection at 12% FPR. Confidence gate as referral: 14% precision (harmful).
Override learning: +1.1pp at 1,500 decisions (premature — needs ≥50 positives).
Architecture: scoring (ProfileScorer, A=4) → referral (ReferralRules, VETO) →
override learning (v6.5+, data-gated). Three concerns, three mechanisms.

---

## 12. Open Math Issues for v5.5 and v6

| Issue | Depends On | Blocks | Status |
|---|---|---|---|
| IKS κ* value | L2 margin at realistic AUAC | v5.5-R4 (IKS display) | **✅ RESOLVED: κ*=0.20 (PROD-1)** |
| σ_max correct value | p10 of L2 margin distribution | Synthesis layer safety | **✅ RESOLVED: σ_max=0.034** |
| λ operative window at realistic AUAC | EXP-S2-REPRO realistic arm | GATE-M | **✅ RESOLVED: validated March 14** |
| Confidence floor 0.70 derivation | Accuracy-vs-threshold per category | refer_to_analyst routing | **✅ RESOLVED: PROD-4 validated, A=4. Referral via ReferralRules, not confidence.** |
| S4 bound at 2pp accuracy degradation | Per-cell drift vs accuracy sweep | IKS saturation threshold | Pending (PROD-1b) |
| Minimum verification rate floor | Three monitored conditions | Core compounding claim | ⚠️ Partially characterized |
| Segmented accuracy by alert type | Realistic L2 margin distribution | Competitive claims | INTERNAL ESTIMATE |
| Bridge A: Level 2 poisoning | EXP-L2-POISON design | v6.0 Level 2 safety | Planned |
| Bridge B: ρ per source pair | Empirical source correlation | σ²_G precision | Shadow mode data |
| Bridge A: θ_min calibration | N_half + deployment V + α | Conservation law threshold | **✅ FORMULA FIXED: θ_min = 23.53/(α×V), α = cumulative category coverage. 23.53 is empirically calibrated (cold-start interlock, non-binding in steady state); principled first-principles derivation = OPEN. Deprecated hardcoded 0.467.** |
| **DiagonalKernel on real data** | **FX-1 real SOC data** | **Production kernel validation** | **Pending (v6.0 first customer)** |
| **Per-customer τ calibration** | **TD-034 on real alert stream** | **Deployment qualification** | **Pipeline built (P28). Awaiting customer.** |
| **Override learning activation** | **≥50 positive referral examples** | **v6.5 referral ML** | **Data-gated. At V=200: ~8 days. At V=50: ~50 days.** |
| **R2/R7 Neo4j wiring** | **DecisionRecord queries for sequence_count, cross_category_count** | **Rules R2, R7 live in production** | **Pending wiring. R1,R3-R6 work immediately.** |
| **Re-Convergence Theorem (γ > 1)** | **Analytic proof from centroid update equations** | **CC-21 Tier 1 (EXP-G1), Claims Registry §B.5** | **✅ RESOLVED: γ > 1 ⇔ ε_firm > 0.125 [corrected April 8 from 0.128 to 0.125]. Proven by 4 LLMs (April 8, 2026). See §3.2. EXP-G1 provides empirical measurement.** |
| **DK characterization surface at scale** | **Controlled 1500-cell parameterization with clean cold-start/asymptotic decomposition** | **Deliverable 1 cumulative-methodology retraction; math blog regeneration** | **✅ RESOLVED: UNI-DK-01 v5.3 (April 19, 2026). +7.67pp at NR=5.0 asymptotic, monotone in NR, D1-D4 all PASS, D5 dropped. See §3.3 and §8.** |
| **Cold-start vs learning decomposition methodology** | **Point-in-time measurement via frozen no-learning scorer + rolling-window asymptotic** | **Math blog Part 2 narrative; claims registry B3 gate condition** | **✅ RESOLVED: v5.3 methodology supersedes v4.2 cumulative-averaging. "Negative learning at low NR" retracted as measurement artifact.** |
| **DK calibration properties at scale** | **ECE measurement on both kernels across NR range** | **Production touchpoint designs (auto-pause, q, triage)** | **✅ CHARACTERIZED (v5.3): DK ECE rises 0.055→0.42 across NR=1.0→5.0; L2 stays 0.04-0.06. Downstream consequences architecturally addressed (§3.3, §9, §16).** |
| **Conservation-law q operational definition** | **Choice of signal (confidence vs accuracy) given DK calibration finding** | **B5 production deployment with DK routed; EU AI Act Article 14 argument** | **✅ RESOLVED: q = rolling verified accuracy over last 400 decisions (§5, §9). v13 derivation preserved under substitution. Codex audit (O14) confirmed no step implicitly required q = confidence.** |
| **KernelSelector architecture decision** | **Option A (NR-rule) vs B (accuracy-comparison) vs C (calibrated-confidence)** | **v6.0 GAE-05 ship** | **✅ RESOLVED: Option A (NR-rule). Validated twice — V-MV-KERNEL 4/4 + UNI-DK-01 v5.3 E3 100%. B retained as v6.1 contingency. C archived.** |
| **Auto-pause signal source** | **Per-decision vs state-level trigger; confidence vs accuracy signal** | **v6.0 production readiness for DK** | **✅ RESOLVED: State-level trigger on rolling verified accuracy (same signal as q). §9 S6 updated.** |

**v14 note on resolved issues count:** Five issues closed in v14 (DK surface, decomposition
methodology, DK calibration characterization, q operational definition, KernelSelector
architecture, auto-pause signal). Total resolved in synopsis history: ~20.

---

## 13. Claims Evolution Roadmap

### Gate KERNEL: DiagonalKernel Validated (March 21, 2026)

**Prerequisites:** V-MV-KERNEL factorial (390 cells, 2 domains). V-HC-CONFIG (3
conditions, 15 seeds). 4 healthcare personas (Corr=0.990). Selector fixes (rolling
window, simplified rule).

**Unlocks:**
- **CL-KERNEL-COMPOUND:** "The distance metric itself compounds. DiagonalKernel at
  Day 30 outperforms L2 by up to 13pp on SOC heterogeneous noise data." [v14: "up to"
  qualifier added for curve-based citation]
- **CL-KERNEL-SELECT:** "The system automatically selects the optimal kernel for the
  deployment's factor noise profile. Rule: noise_ratio > 1.5 → Diagonal."
- **CL-NOISE-CEILING-REVISED:** "With DiagonalKernel, learning is viable at
  σ_mean ≤ 0.25 (was 0.157 with L2). Healthcare deployments open."
- **CL-HC-OPENS:** "Healthcare SOCs can enable learning from Day 1 with DiagonalKernel.
  +3.7pp learning lift at σ=0.22 where L2 produces +0.3pp."
- Factor quarantine mask DEPRECATED — Diagonal supersedes (binary→continuous weighting).
- ShrinkageKernel deprioritized to v7.0 (off-diagonal <1pp in both domains).

**Remains forbidden:**
- "DiagonalKernel validated on production data" (needs v6.0 first customer)
- Any claim mixing L2 and Diagonal numbers without stating which kernel

---

### Gate P0-FIX: Asymmetric η Validated (March 19, 2026)

**Prerequisites:** 9-persona stress test (B5B-PROXY). η-SWEEP (54 runs). Phase 1
quality sweep (1C, 5 personas across q̄=0.57-0.91).

**Unlocks:**
- **CL-ASYMMETRIC-ETA:** "Override learning attenuated 5× (η_override=0.01) prevents
  13-27pp centroid degradation from realistic analyst quality."
- **CL-QUALITY-ROBUST:** "Learning produces positive lift at all tested analyst quality
  levels (q̄=0.57 to 0.91) with η_override=0.01."
- N_half claim qualified: "N_half ≈ 14 at q̄≥0.70 AND σ≤0.157 (L2) / σ≤0.25 (Diagonal)."

---

### Gate A4-CONFIRM: A=4 Action Space Confirmed (March 21, 2026)

**Prerequisites:** EXP-A4-DIAGONAL (A=4 vs A=5 under DiagonalKernel). Coding session
code inspection (GAE implements A=4, 478 tests). V-MV-KERNEL ran at A=4.

**Unlocks:**
- **CL-A4-ACCURACY:** "A=4 (escalate, investigate, suppress, monitor) achieves 90.6%
  frozen scorer accuracy, up from 80.4% at A=5. Zero dangerous actions."
- **CL-A4-STRUCTURAL:** "The 13pp gap between A=4 and A=5 is structural — centroid
  geometry confusion, not fixable by kernel weighting."
- refer_to_analyst permanently removed from centroid tensor. Accessed via confidence
  gate (action routing) and ReferralRules (referral routing).

**Remains forbidden:**
- "A=5 is better" or any claim implying refer_to_analyst belongs in the tensor.
- Using A=5 numbers (80.4% frozen scorer) as current product claims.

---

### Gate REFERRAL: ReferralRules R1-R7 Validated (March 21, 2026)

**Prerequisites:** EXP-REFER-COVERAGE (10-reason taxonomy, 5,000 alerts). EXP-REFER-LAYERED
(4 layers × 300 runs, 19 features, 1,500 warmup). 478 GAE + 280 SOC tests.

**Unlocks:**
- **CL-REFERRAL-RULES:** "Policy-based referral rules R1-R7 detect 72.7% of alerts
  needing human review at 12% false positive rate."
- **CL-REFERRAL-VETO:** "Referral routing is independent of and cannot contaminate
  action scoring. VETO inserts after composite gate, before response build."
- **CL-CONFIDENCE-NOT-REFERRAL:** "The confidence gate is NOT a referral mechanism.
  At 14% precision, it wastes 86% of analyst referral time."
- Override learning data-gated at v6.5 (≥50 positive examples).

**Remains forbidden:**
- "Confidence-based referral is effective" (14% precision = actively harmful).
- "Override learning works at low volume" (needs ≥50 positives, ~8 days at V=200).
- "Rules catch all referral patterns" (20.7% emergent fraction requires override learning).

---

### Gate GAMMA: Re-Convergence Theorem Established (April 8, 2026)

**Status:** Tier 2 QUALIFIED. **Signal tier:** T-arch (theorem) + T-sim (γ≈1.2 simulation).
Analytic proof + simulation + production-faithful
experiment (May 2026). Binary prediction confirmed. Effect size γ ≈ 1.2 (L2),
not γ ≥ 4.6 (idealized). DK with stale weights reverses effect (CLAIM-DK-STALE).
EXP-G1 pilot data remains the path to Tier 1.

**Prerequisites:** Oracle separation validation (v6/v8/v11/v2/v3/final, April 8, 2026).
LLM math poll v4: GPT-4.1, Claude Opus 4, Grok 3, Gemini 1.5 Pro.
BACKLOG-015: EXP-G1 logging active from pilot Day 1.

**The theorem (see §3.2 for full derivation):**

```
γ > 1   ⟺   ε_firm > ε_firm★ ≈ 0.125

where ε_firm★ = α_disrupt · ‖Δ‖ / (1 − α_disrupt)  [θ cancels; corrected April 8]

Production ε_firm: 0.15–0.40  (clears threshold)
Simulation ε_sim: 0.05         (below threshold — correctly predicted γ < 1)
```

**Binary simulation confirmation:**
- ε_sim = 0.05 (below 0.125): γ = 0.714 < 1 ✓
- ε_sim = 0.20 (above 0.125): γ = 1.033 > 1 ✓

**Unlocks:**
- **CC-21 Tier 2 (signal: T-arch + T-sim):** "The system recovers from disruptions faster than it first calibrated."
  State with conditions: category-sparse disruption, warm-started centroids, ε_firm > 0.125.
- **CLAIM-GAMMA-THEOREM:** In Claims Registry v6.3 §B.5 — Tier 2, QUALIFIED (signal: T-arch).
  The composition rule (§Certification) explains why γ is Tier 2 not Tier 1: it lacks T-pilot signal.
  EXP-G1 pilot data remains the path to Tier 1 (signal upgrade: T-sim → T-pilot).
- **EXP-G1 design:** centroid_distance_to_canonical is the primary metric (N_half is a
  noisy proxy — see §3.2 N_half Measurement Gap).

**Conditions (must state alongside any commercial claim):**
1. Category-sparse disruption: c_d/C ≈ 0.33
2. Warm-started centroids: Phase 1 has converged
3. ε_firm > 0.125 (verifiable from centroid_distance_to_canonical in production logs)

**Path to Tier 1:** EXP-G1 — 90-day pilot data with L2 kernel during first
disruption recovery. centroid_distance_to_canonical logged per verified decision
(BACKLOG-015 active). Production-faithful experiment (May 2026) predicts
γ ≈ 1.2 for L2. Pilot measurement will be definitive.

**Forbidden:** "Re-convergence is always faster." The theorem is QUALIFIED (must state L2 kernel + conditions). See Claims Registry v6.3 §F9.

---

### Gate JM-APPARATUS: JM Redesign Results Measured (September 2026)

**Status:** Tier 2 QUALIFIED. **Signal tier:** T-real-sim (JM apparatus, 40 deployments,
5,000 bootstrap resamples).

**Prerequisites:** JM redesign harness v6 (jm_redesign_results_note_v6). 40 synthetic
deployments across varied scenario configurations. 5,000 bootstrap resamples per metric.
Frozen-twin baseline (decision-0 snapshot, no learning).

**Unlocks:**
- **CL-CUMULATIVE-ADVANTAGE (C1):** "Cumulative K-learning advantage over a frozen twin
  scales super-linearly: c = 1.387, 95% CI [1.308, 1.477] (interval excludes 1). The
  advantage curve is unbounded; accuracy saturates logistically (c_acc = 0.643, sub-linear
  by construction)." Signal: T-real-sim.
- **CL-ACCURACY-GAIN (C4):** "K-learning improved bounded decision quality by +21.96
  percentage points over a frozen twin." Signal: T-real-sim.
- **CL-DISCOVERY-SCALING (C2):** "SDK cross-domain discoveries scaled as α_d = 2.150,
  95% CI [2.030, 2.299] across domains and β_d = 2.622, 95% CI [2.436, 2.964] across
  sequential evidence sweeps." Signal: T-real-sim. Upgrades VLD b=2.11 (T-sim).
- **CL-CONSERVATION-PERTHREAT (C3):** "Conservation gate detected sustained corruption,
  gradual drift, and sudden change in 100% of trials (0% FPR); sparse adversarial 10%
  injection detected in 57%, defining the measured sensitivity boundary." Signal: T-real-sim.

**Path to Tier 1:** Real-data longitudinal validation (6–12 months operational data) =
T-pilot gate. EXP-G1 (90-day pilot) measures re-convergence γ (a distinct quantity from
the cumulative advantage c = 1.387).

**Remains forbidden:**
- "Accuracy compounds super-linearly" (accuracy is bounded; c_acc = 0.643 is sub-linear
  by construction — landmine rule).
- Stating JM numbers without "JM apparatus" or "measured" qualifier (they are T-real-sim,
  not T-pilot).
- Confusing c = 1.387 (cumulative advantage) with γ ≈ 1.2 (re-convergence ratio) —
  different quantities, different experiments.
- Citing the old bootstrap CI [0.355, 1.817] — this was on accuracy (wrong target);
  resolved by the JM apparatus measuring cumulative advantage directly.

---

**INVARIANT (A0) — acquisition, not depth (engine I3, T-arch).**
With the graph and Θ frozen and enrichment inert, the refinement operator reduces to a fixed map: iterating
over unchanged evidence cannot improve the decision. Reasoning depth is state-conditioned *acquisition*
(route+enrich), never loop count. Proven; empirically confirmed by the recurrence-ladder null (adding
recurrent depth over fixed evidence does not help and mildly hurts). Signal tier: T-arch (by construction) +
T-geom (confirmation). This bounds what any loop can claim from iteration alone.

**CLAIM-4READOUT — the confidence readout is carried by the investigation trajectory.**
A single investigation yields four readouts (which evidence, how much, better action, confidence); these are
loop **outputs** (architecture), not engine operations. The load-bearing claim for the ledger: the per-
decision confidence is carried by trajectory features (delta_1, post-investigation margin) — an ablation
drops confidence discrimination to AUC 0.642 (below the 0.650 population baseline) when trajectory features
are removed; geometric features contribute nothing; per-copilot AUC 0.809–0.875. Signal tier: T-geom.
Maturity tier: Tier 2. Note: this certifies the confidence readout only; the other three readouts are
capability claims tracked in the capability docs, not the math ledger.

### Gate UNI-DK-01: DiagonalKernel Characterization Surface (April 19, 2026)

**Prerequisites:** Spec evolution v1→v5.3 with methodology flaw discovery (cumulative
vs instantaneous accuracy semantics, v4.2 post-run audit). 1500-cell execution
(5 NR × 5 q̄ × 30 seeds × 2 kernels). Frozen-centroid no-learning scorer implementation
for cold-start measurement. 400-decision rolling deque for asymptotic measurement.
D1-D4 verification (D5 dropped as tautological).

**Status:** PUBLISH. All four pre-registered checks pass (D1 monotonicity, D2 NR=5 ≥ 5pp,
D3 cs_pct ≥ 50%, D4 q̄-std ≤ 1pp). Supersedes Deliverable 1 decomposition tables
(cumulative-averaging methodology retracted).

**Experiment data on Drive:** `DRIVE_BASE/uni_dk_01/uni_dk_01_v5_*.json`
(decomposition, trajectory, q_invariance, e1_decision, e2_ece, e3_diagnostic,
e4_stability, w_convergence, verification). v4.2 outputs archived at
`archive_v4_2/`. `v_mv_kernel_rerun_v1.json` and `v_mv_kernel_rerun_v3.ipynb`
archived.

**Unlocks:**
- **CL-DK-CHARACTERIZED:** "DK advantage over L2 scales monotonically with noise
  heterogeneity: 0.00pp at uniform σ (NR=1.0, mathematical identity confirmed),
  +0.72pp at NR=1.5, +1.99pp at NR=2.0, +4.43pp at NR=3.0, +7.67pp at NR=5.0
  (asymptotic, mean-σ=0.175 fixed, 150 paired cells per NR)."
- **CL-DK-CURVE-CITATION:** "DK accuracy advantage is curve-based: up to +13.2pp
  peak on heterogeneous SOC data (V-MV-KERNEL-HET, 390 cells), +7.67pp characterized
  at controlled NR=5.0 mean-σ=0.175 (UNI-DK-01 v5.3, 1500 cells). 1890 cells total
  across two independent experiments."
- **CL-COLD-START-CONTRIBUTOR:** "Cold-start scoring geometry is the larger
  contributor across all measured noise regimes. Peak at NR=2.0 (75.5% of asymptotic
  gap), declines to 54.5% at NR=5.0 as learning grows faster than cold-start at
  extreme heterogeneity." [Replaces earlier "cold-start dominates at high NR" which
  was derived from cumulative measurement.]
- **CL-DK-POSITIVE-LEARNING:** "Learning contributes positively at every NR level
  (+0.19pp to +3.49pp, NR=1.5 to NR=5.0). Previously reported 'negative learning at
  low NR' was a cumulative-averaging measurement artifact, now retracted."
- **CL-Q-INVARIANCE:** "Cold-start advantage is q̄-independent. Max q̄-std across
  the 5-level q̄ sweep is 0.285pp at NR=2.0, against a 1.0pp threshold (PASS by 3.5×).
  v4.2 cumulative measurement reported 1.22pp (FAIL); the failure was learning
  contamination, not a real q̄ dependency."
- **CL-KERNEL-RULE-VALIDATED:** "Rule-based kernel selection (NR > 1.5 → DK) is
  100% correct at every informative NR in v5.3 (91/91, 2/2, 49/49, 127/127 cells
  at NR=1.5/2.0/3.0/5.0 respectively). Combined with historical V-MV-KERNEL HC-personas
  4/4, two independent validations of the NR-threshold rule."

**Companion finding (not a claim unlock, but architecturally consequential):**
- **DK calibration properties characterized:** ECE rises from 0.055 at NR=1.0 to 0.42
  at NR=5.0 for DK; L2 stays 0.04-0.06. Mechanism: W-concentration reduces effective
  dimensionality, sharpens softmax, produces overconfidence. Addressed architecturally
  at every production consumption point (§3.3 downstream consequences table, §9 S6,
  §16 constraints).
- **Confidence-based kernel selection unreliable:** mean_conf always selects L2 even
  at NR=5.0 where DK has +7.67pp accuracy advantage (E4 winner_stability_rate=1.000
  at all NR, dk_final_share=0.000). Mean_ll is below chance at NR ≥ 3.0 (E3
  data-driven 0.37-0.53). These findings confirm that confidence-based KernelSelector
  (Options B/C in early design) cannot work without calibration; the NR-rule
  (Option A) sidesteps the issue entirely.

**Remains forbidden:**
- "DK validated in production" (still awaits v6.0 first customer).
- "DK is more reliable than L2" without kernel-specific qualifier — DK is more
  accurate but less calibrated; the comparison depends on which property matters.
- Citing DK confidence as production signal for auto-pause, q-tracking, or analyst
  triage (use accuracy or entropy instead — see §9 S6, §5 q definition).
- Single-number DK citations without context. Use curve-based citation:
  "up to +13.2pp peak (V-MV-KERNEL-HET), characterized +0pp to +7.67pp across
  NR=1.0 to NR=5.0 (UNI-DK-01 v5.3)."

**Deprecations triggered by this gate:**
- Deliverable 1 decomposition tables (`v_mv_kernel_summary_v2.md`) — retained for
  historical context with "superseded" annotation.
- "Negative learning at low NR" finding — retracted.
- "Cold-start dominates at high NR" narrative — replaced with "cold-start is the
  larger contributor across all noise regimes."
- Confidence-based KernelSelector as design option — archived.
- Confidence-based AMBER auto-pause — replaced with rolling-accuracy trigger.
- Confidence-based conservation-law q — replaced with rolling verified accuracy.

---

## Appendix C — v5.5 Requirements (historical; see MAP for current status)

### v5.5-T1-1: NL Template Engine [CRITICAL — Demo Q1]
**Status:** ✅ SHIPPED. 24 templates (6 categories × 4 actions). Three layers.
Deterministic. No LLM dependency. "Similar past cases" sidebar implemented.

### v5.5-R1: Auto-Approve Coverage 40%+ [CRITICAL — Demo Q3]
**Status:** ✅ SHIPPED. A=4 + PROD-4 per-category thresholds achieve 40%+ coverage
at ≥85% per-category accuracy. Three-tier dispatch: auto-approve / investigate / review.

### v5.5-R4: Institutional Knowledge Score [CRITICAL — Demo Q2]
**Status:** ✅ SHIPPED. IKS(t) with κ*=0.20 (PROD-1 calibrated). Tab 2 header.

### v5.5-R3: Chart A — Centroid Drift Visualization
**Status:** ✅ SHIPPED. Corrected metric.

### v5.5-R5: Factor Node Provenance
**Status:** ✅ SHIPPED. ProvenanceNode per factor.

### v5.5-R6: Alert Type → Category Mapping Fix
**Status:** ✅ SHIPPED. GATE-R: 100% routing accuracy.

### v5.5-R7: Threat Intelligence Write-Back
**Status:** ✅ SHIPPED. ThreatIndicator nodes with 24h TTL.

### v5.5-R8: Shadow Mode + Shadow Report
**Status:** ✅ SHIPPED. PROD-3 calibrated agreement rates.

### v5.5-NEW: Actions = 4 (A=4 migration)
**Status:** ✅ SHIPPED. escalate, investigate, suppress, monitor. refer_to_analyst
via referral rules R1-R7 (not confidence gate). Static accuracy 80.6→90.6%. Zero dangerous actions.

### v5.5-NEW: Evidence Ledger + EU AI Act Compliance
**Status:** ✅ SHIPPED. Hash-chained, tamper-evident.

### v5.5-NEW: PyPI Release
**Status:** ✅ SHIPPED. GAE v0.7.0 on PyPI. 478 tests.

---

## Appendix D — v6.0 Requirements (historical; see MAP for current status)

### v6-KERNEL: DiagonalKernel as Default
**Status:** Code complete. 478 GAE tests.
DiagonalKernel(W=diag(1/σ²)) default for noise_ratio > 1.5. L2 fallback.
**KernelSelector architecture (v14 settled):** Option A (NR-threshold rule). Rule
validation: V-MV-KERNEL HC-personas 4/4 + UNI-DK-01 v5.3 E3 100% correct. Option B
(accuracy-comparison) retained as v6.1 contingency if P28 σ estimation proves
unreliable in the field. Option C (calibrated-confidence) archived — no scenario
requires it.
KernelSelector: Phase 2 rule + Phase 3 rolling comparison (100-window) + Phase 4 lock
at **max(1000, 20×V×α) decisions** (corrected from "~250 decisions" — V-GATE-STABILITY
confirms all three baselines require N=1000 minimum; binding constraint is volume baseline
(≥20 days). "250 decisions" figure is deprecated.] CovarianceEstimator collects data
(half_life=300 decisions, does not affect scoring — v7.0 research).

### v6-P0: Asymmetric η
**Status:** ✅ Code complete. η_confirm=0.05, η_override=0.01. 24 personas validated.
v5.3 confirms positive learning contribution at every NR level (+0.19pp to +3.49pp).

### v6-PAUSE: AMBER Auto-Pause
**Status:** ✅ Code complete. Conservation AMBER/RED → freeze learning → GREEN resumes.
**v14 update:** Trigger signal changed from confidence-based to rolling verified accuracy
over last 400 decisions. Same signal that powers conservation-law q. State-level
transition (not per-decision filter). Resume condition: rolling accuracy recovers above
threshold for ≥100 consecutive decisions. Per-decision uncertainty gating (softmax
entropy / confidence gap) is a separate concern spec'd in gae_design, not part of
auto-pause. See §9 S6 for full specification.

### v6-ROI: Frozen Mode ROI Calculator
**Status:** ✅ Code complete. 44min × V × cost, NOT $127/alert. Three value drivers.

### v6-REFERRAL: ReferralRules R1-R7
**Status:** ✅ Code complete. 280 SOC tests. ReferralRules R1-R7 as VETO mechanism
after composite gate. 72.7% detection rate, 12% FPR. Deterministic pure functions.
Safe defaults (missing context → rule doesn't fire). R2 (sequence_count) and R7
(cross_category_count) need Neo4j query wiring for production — R1, R3-R6 work
immediately from alert metadata. Override learning (OverrideDetector) data-gated
at v6.5: activates when ≥50 positive examples in override buffer.

### v6-R1: Synthesis Layer (conditional — GATE-M + GATE-D required)
[Unchanged from v9.1]

### v6-R2: Attack Chain Correlation
[Unchanged from v9.1]

### v6-R3: Real SIEM Integration (Splunk + Sentinel)
**Status:** ✅ Code complete. ci-platform connectors: sentinel.py, splunk.py,
sentinel_writeback.py. SourceConnectorProtocol ABC.

### v6-R4: S2P Second Domain
**Status:** S2PDomainConfig d=8 created. 5 categories × 5 actions × 8 factors.
Correlation prior (Regime A, 28 pairs from two-judge research). penalty_ratio=5.0.
SOC A=4 / S2P A=5 — intentional asymmetry.

### v6-R5: Autonomy Envelope Widening
[Unchanged from v9.1]

### v6-R6: Centroid Editor UI / Management API
[Unchanged from v9.1]

### v6-R7: Analyst Benchmarking Report
**Status:** ✅ Code complete (L-04). Per-shift quality breakdown.

### v6-NEW: Deployment Qualification Pipeline (P28)
**Status:** ✅ Code complete. ci-platform. 6 phases:
Import → Compute (TD-034 + σ_mean + remediation) → Shadow → Qualify → Enable.
DeploymentQualifier: GREEN/AMBER/RED classification. 73 ci-platform tests.

### v6-NEW: SAML + PII + Entity Resolution
**Status:** ✅ Code complete. ci-platform. SAML auth, PII redaction (5 patterns,
3 strategies), entity resolution: **exact-match pipeline complete** (_normalize,
_build_merge_groups, union-find, IdentifierType enum — deterministic canonical IDs).
**Probabilistic fuzzy matching (Jaccard token overlap) NOT present — pending Block 6.1.**
(note: "3-pass pipeline, deterministic canonical IDs" overstated — exact-match
is built, fuzzy matching is not. Confirmed by code audit April 1, 2026.]

---

## 16. Constraints & Invariants

| Constraint | Source | Enforced By | Status |
|---|---|---|---|
| μ ∈ [0, 1]^d | V2 (centroid escape without clipping) | np.clip after every update | ✅ VALIDATED |
| τ = 0.1, fixed | V3B (ECE=0.036 vs 0.19 at τ=0.25) | CalibrationProfile default | ✅ VALIDATED |
| η_neg = 0.05 (canonical, symmetric with η) | η_neg=1.0 FORBIDDEN (ECE=0.49). | CalibrationProfile default | ✅ VALIDATED |
| **η_confirm = 0.05** | **P0 fix: confirm path, clean signal** | **ProfileScorer.update()** | **✅ VALIDATED** |
| **η_override = 0.01** | **P0 fix: override path, noisy signal. Prevents 13-27pp degradation. v5.3 confirms positive learning at every NR.** | **ProfileScorer.update(eta_override=)** | **✅ VALIDATED (24 personas + UNI-DK-01 v5.3)** |
| **θ_min = 23.53/(α×V)** | **Deployment-specific conservation floor; α = cumulative category coverage. 23.53 is an empirically calibrated constant (cold-start interlock), NOT first-principles-derived — the prior "N_half × η × V_min" derivation is retired (see §9 θ_min provenance). Equivalently α²·q·V² ≥ 23.53; A1-R2 measures V_clear ≈ 3 (range 3.0–3.3 across five copilots), with the earlier coverage-specific V≈8/16/32 estimates superseded; non-binding in steady state. The old "V=50, α=0.25 → θ_min=1.88 impossible" example used override-rate α and is withdrawn. Formally equivalent to CLAIM-SC-01 scope condition.** | **compute_theta_min(α,V)** | **✅ FORMULA VALIDATED; derivation empirical** |
| **Conservation-law q = rolling verified accuracy over last 400 decisions** | **Operational definition of q in α·q·V ≥ θ_min. v13 derivation preserved under substitution. DK calibration finding (ECE 0.42 at NR=5.0, v5.3 §3.3) motivates switch from confidence to accuracy. Strengthens EU AI Act Article 14 argument.** | **ConservationMonitor.compute_q() → rolling_accuracy_400()** | **✅ VALIDATED (v5.3)** |
| **AMBER auto-pause on rolling accuracy** | **Conservation AMBER/RED → freeze learning. Trigger: rolling verified accuracy drops below (baseline × 0.9) or absolute floor. State-level, not per-decision. Resume after ≥100 consecutive decisions above threshold.** | **ProfileScorer.set_conservation_status()** | **✅ IMPLEMENTED** |
| **DiagonalKernel default for noise_ratio > 1.5 (KernelSelector Option A)** | **Rule-based selection. Two validations: V-MV-KERNEL HC-personas 4/4 + UNI-DK-01 v5.3 E3 100% (91+2+49+127=269 informative cells). Confidence-based selection (B, C) tested and rejected: mean_conf always picks L2, mean_ll below chance at NR≥3.** | **KernelSelector Phase 2 rule** | **✅ VALIDATED (390 cells + 1500 cells)** |
| **KernelSelector architecture: Option A (NR-rule) for v6.0. Option B (accuracy-comparison) as v6.1 contingency. Option C (calibrated-confidence) archived.** | **UNI-DK-01 v5.3 E1/E3/E4: confidence-based selection untenable due to DK's calibration properties. NR-rule sidesteps the issue.** | **gae_design v10.7 KernelSelector spec** | **✅ DECIDED (v14)** |
| **KernelSelector shadow minimum: max(1000, 20×V×α)** | **V-GATE-STABILITY: N=1000 required for all three baselines. Binding constraint: volume baseline needs ≥20 days. "~250 decisions" figure deprecated.** | **P28 Phase 3 configuration** | **✅ VALIDATED** |
| **ShrinkageKernel NOT shipped at v6.0** | **Off-diagonal <1pp in both domains** | **Not implemented** | **✅ DEPRIORITIZED** |
| **Noise ceiling kernel-dependent** | **L2: σ≤0.157. Diagonal: σ≤0.25. V-B3: three-variable.** | **P28 deployment qualification** | **✅ VALIDATED** |
| **Factor mask DEPRECATED** | **V-HC-CONFIG: mask hurt Day 1 by 6pp. Diagonal supersedes.** | **DiagonalKernel replaces** | **✅ DEPRECATED** |
| **DK confidence outputs NOT safe for direct downstream consumption** | **UNI-DK-01 v5.3 §3.3: DK ECE rises 0.055→0.42 across NR=1.0→5.0. Property of inverse-variance weighting, not defect. Production touchpoints (auto-pause, q, triage) must use alternative signals: rolling accuracy, softmax entropy, or confidence gap as appropriate.** | **Architectural: no production component consumes raw DK max_p** | **✅ RESOLVED (v14)** |
| σ ∈ [−σ_max, +σ_max] | Safety S3; **σ_max=0.034** | RuleBasedProjector clipping | ✅ Resolved |
| Loop 2 never uses σ | Epistemic separation | ProfileScorer.update() ignores σ | ✅ Enforced |
| LayerNorm before Tier 5 | V1B (2.9M× explosion without it) | Required for embedding ops | ✅ VALIDATED |
| Centroids readable by humans | Architecture choice — auditability | μ[c,a,:] is inspectable d-vector | ✅ Design |
| ProfileScorer is THE scorer | TD-029 (ScoringMatrix deprecated) | ScoringMatrix removed | ✅ v5.0 |
| τ_mod = REJECTED | ECE +0.138 at any τ_mod ≠ 1.0 | Removed from all equations | ✅ REJECTED |
| **n_act = 4 (SOC v6.0 canonical)** | **A=4 migration: 80.6→90.6%, zero dangerous actions. 13pp structural (EXP-A4-DIAGONAL).** | **DomainConfig** | **✅ v6.0** |
| n_cat = 6 (SOC v5.0+) | threat_intel_match added. ORDER PERMANENT. | DomainConfig | ✅ v5.0+ |
| **ReferralRules R1-R7 (VETO)** | **EXP-REFER-LAYERED: 72.7% DR, 12% FPR. Confidence gate = 14% precision (harmful for referral).** | **ReferralRules after composite gate. Cannot affect ProfileScorer scoring.** | **✅ SHIPPED (280 SOC tests)** |
| **Per-analyst η weighting (η_i)** | **D5 validated: CONDITIONAL 0.86pp. V-D5-MECHANISM-GATE PATH 1, regime-independent (Spearman r=0.975–1.000). η_i = clip(precision_i / mean_precision, 0.5, 1.5) × η_override. Subsumes D6.** | **ProfileScorer.update() per-analyst weight** | **✅ CONDITIONAL — production gate ≥1.0pp** |
| **D6 (night-shift attenuation): CLOSED** | **V-NIGHT: two attempts, both inverted. Explicit override rules cannot model fatigue. D5 continuous precision monitoring subsumes D6 — precision drops for any reason automatically.** | **Subsumed by D5** | **✅ CLOSED** |
| **FINDING-OVR-01** | **Override precision structurally uncorrelated with q̄. V7: r=0.00. V3: r=-0.70. Must be measured directly per analyst — not predictable from role, seniority, or agreement rate.** | **Must measure directly** | **✅ EMPIRICAL FINDING** |
| **Self-calibrating gate principle** | **All operational gates derived from deployment's own shadow data. V-GATE-DRIFT: baselines stable within 7% across 90-day pilot. No monthly recalibration needed.** | **GateConfig class: conservative fallbacks before N_min, calibrated after** | **✅ VALIDATED** |
| Verification rate health | Three conditions: coverage, drift, conservation law | Three conditions monitored | ⚠️ Partially characterized |
| N3 endogenous loop | Known calibration-feedback risk | **No intervention designed** | ⚠️ Known risk |
| Conservation law: α(t)·q(t)·V(t) ≥ θ_min | Level 2 must not cannibalize Level 1 signal. q = rolling verified accuracy (v14). | Eq. GATE-L2 condition (3) + Eq. CL | ✅ DESIGNED |
| Centroid support: each (c,a) within data support | Push-away can retire centroid (Opus finding) | Monitor ‖f − μ[c,a,:]‖ < D_support | ⚠️ Monitoring needed |
| Variant variance stability | Level 2 variant must not be volatile | Eq. GATE-L2 condition (4) | ✅ DESIGNED |
| **LEARNING_ENABLED = False default** | **Enable per-customer after shadow qualification** | **P28 deployment pipeline** | **✅ IMPLEMENTED** |

---

## 17. Equation Index

| Equation | Status | Location | Purpose |
|---|---|---|---|
| **Eq. 4-final** | ✅ VALIDATED | §3 | L2 distance scoring (cold-start fallback) |
| **Eq. 4-diagonal** | **✅ VALIDATED (V-MV-KERNEL + UNI-DK-01 v5.3)** | **§3** | **DiagonalKernel scoring (deployment-specific option; L2 is production default). Characterized surface in §3.3.** |
| **Eq. 4b-final** | ✅ VALIDATED | §3 | Centroid pull/push learning (asymmetric η) |
| **Count decay** | ✅ VALIDATED | §3 | Stability from experience |
| **Eq. IKS** | ✅ VALIDATED (κ*=0.20) | §3 | Institutional Knowledge Score |
| **Eq. T*** | ✅ VALIDATED (PROD-4, A=4) | §3 | Category-specific auto-approve |
| **Eq. CONV** | ✅ THREE-JUDGE VALIDATED | §3.1 | Mean error dynamics: (1−η)^n |
| **Eq. MSE∞** | ✅ THREE-JUDGE VALIDATED | §3.1 | Steady-state MSE: η·tr(Σ_f)/(2−η) |
| **Eq. N_CONV** | ✅ THREE-JUDGE VALIDATED | §3.1 | Convergence time to calibration neighborhood |
| **Eq. GAMMA-THEOREM** | ✅ 4-LLM VALIDATED | §3.2 | γ > 1 ⟺ ε_firm > ε_firm★ |
| **Eq. GAMMA-THRESH** | ✅ 4-LLM VALIDATED | §3.2 | ε_firm★ = α_disrupt · ‖Δ‖ / (1 − α_disrupt) ≈ 0.125 |
| **Eq. GAMMA-P_D** | ✅ 4-LLM VALIDATED | §3.2 | Effective Phase 2 threshold p_d★ = 0.55 |
| **Eq. GAMMA-DIST** | ✅ 4-LLM VALIDATED | §3.2 | centroid_distance_to_gt (EXP-G1 metric) |
| **Eq. DK-DECOMP** | **✅ VALIDATED (UNI-DK-01 v5.3)** | **§3.3** | **Decomposition: asymptotic_gap = cold_start_gap + learning_gap (point-in-time)** |
| **Eq. DK-ECE** | **✅ EMPIRICAL (UNI-DK-01 v5.3)** | **§3.3** | **DK ECE rises 0.055→0.42 across NR=1.0→5.0; L2 stays 0.04-0.06. Property of inverse-variance weighting.** |
| **Eq. R-L2** | ✅ THREE-JUDGE VALIDATED | §5 | Level 2 composite reward (phase-gated) |
| **Eq. GATE-L2** | ✅ THREE-JUDGE VALIDATED | §5 | Four-condition promotion gate |
| **Eq. CL** | ✅ THREE-JUDGE VALIDATED | §5 | Conservation law: α·q·V ≥ θ_min. q = rolling verified accuracy (v14). |
| **Eq. q-OPERATIONAL** | **✅ VALIDATED (v14)** | **§5, §9** | **q(t) = rolling verified accuracy over last 400 decisions. Replaces per-decision confidence. Robust across kernel choice.** |
| **Eq. σ²_G** | ⚠️ CONDITIONAL (ρ needed) | §10.1 | Graph-dependent factor noise |
| **Eq. η_override** | **✅ VALIDATED (24 personas)** | **§3** | **Asymmetric learning rate formula** |
| **Eq. η_i** | **✅ CONDITIONAL (V-D5, 0.86pp, PATH 1)** | **§3** | **Per-analyst η weighting: η_i = clip(precision_i / mean_precision, 0.5, 1.5) × η_override. Production gate ≥1.0pp.** |
| Eq. 4-synthesis | PROPOSAL (GATE-M pending) | §4 | Scoring with awareness bias |
| Eq. S1 | PROPOSAL | §4 | SynthesisProjector protocol |
| Eq. S2 | PROPOSAL | §4 | Bias accumulation with decay |
| Eq. S4 | PROPOSAL | §4 | GATE-M validation metric |
| ~~Eq. S3 (τ_mod)~~ | **REJECTED** | — | Urgency temperature modifier (ECE +0.138) |
| Eq. 5 (embeddings) | DESIGNED | cross_graph_attention_v3 §4 | Property → embedding (Tier 4, v6.5+) |
| Eq. 6–9 (cross-attention) | DESIGNED | cross_graph_attention_v3 §4–5 | Multi-domain attention (Tier 5, v7+) |

---

## 18. Notation Summary

| Symbol | Meaning | Shape | Range / Value | Status |
|---|---|---|---|---|
| f | Factor vector | (d,) | [0, 1] | ✅ |
| μ | Profile centroids (experience) | (n_cat, n_act, d) | [0, 1] | ✅ |
| σ | Synthesis bias (awareness) | (n_cat, n_act) | [−σ_max, σ_max] | PROPOSAL |
| **W** | **Kernel weight matrix** | **(d, d) diagonal** | **diag(1/σ²_factor). Identity → L2.** | **✅ v6.0** |
| τ | Temperature | scalar | **0.1 — fixed, never change** | ✅ |
| ~~τ_mod~~ | ~~Urgency modifier~~ | — | **REJECTED — ECE +0.138** | ❌ REMOVED |
| λ | Coupling constant | scalar | [0, 0.5]; operative window [0.5, 0.6]. Kill switch at λ=0. | PROPOSAL |
| η | Learning rate (base) | scalar | 0.05 (default) | ✅ |
| **η_confirm** | **Confirm-path learning rate** | **scalar** | **0.05 (clean signal, full rate)** | **✅ v6.0** |
| **η_override** | **Override-path learning rate** | **scalar** | **0.01 (noisy signal, attenuated 5×). P0 fix.** | **✅ v6.0** |
| **η_i** | **Per-analyst learning weight** | **scalar per analyst** | **clip(precision_i / mean_precision, 0.5, 1.5) × η_override. Subsumes D6 (night-shift).** | **✅ CONDITIONAL (D5)** |
| η_neg | Negative learning rate (base) | scalar | **0.05 (canonical). FORBIDDEN: 1.0 (ECE=0.49).** | ✅ |
| decay_rate | Count-based decay | scalar | 0.001 | ✅ |
| c | Category index | int | [0, n_cat); **n_cat=6 (SOC v6.0)** | ✅ |
| a | Action index | int | [0, n_act); **n_act=4 (SOC v6.0). Random baseline = 25% (1/4).** | ✅ |
| K | Kernel function | f,μ → ℝ | **L2 (fallback) or DiagonalKernel (default for noise_ratio>1.5)** | ✅ |
| **G** | **Kernel gradient function** | **f,μ → ℝ^d** | **L2: (f−μ). Diagonal: W·(f−μ).** | **✅ v6.0** |
| n[c,a] | Observation count | (n_cat, n_act) | ℕ | ✅ |
| b | Scaling exponent | scalar | 2.11 ± 0.03 (V1A, **T-sim**, simulation-only) | ✅ (sim) |
| κ* | IKS normalization constant | scalar | **0.20 (PROD-1 validated).** | ✅ Resolved |
| σ_max | Synthesis clipping bound | scalar | **0.034 (FX-1-PROXY-REAL derived).** | ✅ Resolved |
| **θ_min** | **Conservation law floor** | **scalar** | **23.53/(α×V) — deployment-specific formula. Deprecated: 0.467 hardcoded.** | **✅ v6.0** |
| f_min | Minimum verification rate | scalar | **Replaced by three monitored conditions (v9.1).** | Partially characterized |
| IKS | Institutional Knowledge Score | scalar | [0, 100] | ✅ Shipped |
| threshold*(c) | Category auto-approve threshold | (n_cat,) | **PROD-4 validated (A=4).** | ✅ Resolved |
| **noise_ratio** | **max(σ_factor)/min(σ_factor)** | **scalar** | **>1.5 → DiagonalKernel, else L2** | **✅ v6.0** |
| Σ_f | Factor covariance matrix | (d, d) | Positive semi-definite. Use tr(Σ_f) for MSE. | ✅ |
| e_n | Centroid error at step n | (d,) | μ_n − μ* | ✅ |
| N_half | Convergence half-life | scalar | ln(2)/η ≈ 14 at η=0.05. **Qualifier: q̄≥0.70 AND σ≤0.157(L2)/0.25(Diag). UNI-DK-01 v5.3 confirms positive learning at every NR.** | ✅ |
| N_converge | Decisions to calibration neighborhood | scalar | Eq. N_CONV | ✅ |
| α(t) | **Category coverage = c_d/C (cumulative, monotone)** | scalar | [0, 1] — fraction of categories with ≥1 verified decision to date. Cumulative, not windowed: a category that has received verified decisions does not lose coverage. **This is the conservation-law α (distinct from the shrinkage coefficient below).** | ✅ |
| override_rate | Analyst override rate among verified decisions | scalar | [0, 1] — fraction of verified decisions where analyst disagreed with system recommendation (≈ 1−q). **Distinct from α; never substitute into α·q·V.** Feeds the v18 complacency ADVISORY (override_rate < ε_min sustained ≥200 decisions → supervisor dashboard warning), which does NOT affect conservation GREEN/AMBER/RED status. | ✅ |
| α_disrupt | Fraction of alert categories disrupted (c_d/C) | scalar | [0, 1] — re-convergence theorem quantity (§3.2). ≈0.33 for a typical campaign (2/6). **Distinct symbol from the conservation-law α (coverage) and the shrinkage λ (renamed from α in v23); renamed from α_cat in v18.** | ✅ [RENAMED v18] |
| **q(t)** | **Decision quality (operational definition)** | **scalar** | **[0, 1] — rolling verified accuracy over last 400 decisions. Calibration-independent. v14 operational definition replaces confidence-based q. See §5, §9, §16.** | **✅ v6.0** |
| V_verified | Verified decisions per day | scalar | ℕ | ✅ |
| ρ_j | Cross-source correlation for factor j | scalar | [0, 1] — ρ=0.8 typical for SIEMs | ✅ |
| N_eff | Effective independent sources | scalar | N/(1+ρ(N−1)) | ✅ |
| K (Level 2) | Number of prompt variants | scalar | **K=2 recommended (was 3-5)** | ✅ |
| w₁,w₂,w₃ | Level 2 reward weights (phase-gated) | scalars | Sum to 1.0 | ✅ |
| Δ_min | Level 2 promotion threshold | scalar | 0.05 default (5pp improvement) | ✅ |
| N_gate | Samples per arm for promotion | scalar | ≈445 (one-sided, α=0.05, β=0.20) | ✅ |
| D_support | Centroid support radius | scalar | Flag when centroid leaves data support | ✅ |
| **cold_start_accuracy** | **No-learning scorer accuracy over first 400 decisions (UNI-DK-01 v5.3 methodology)** | **scalar** | **[0, 1]. Pure scoring-geometry accuracy with frozen mu_init. Measured via parallel no-update scorer.** | **✅ v14** |
| **asymptotic_accuracy** | **Learning scorer accuracy over last 400 decisions (UNI-DK-01 v5.3 methodology)** | **scalar** | **[0, 1]. Instantaneous via rolling deque(maxlen=400). Not cumulative average.** | **✅ v14** |
| **ECE** | **Expected Calibration Error (L2, DK per-kernel)** | **scalar** | **[0, 1]. L2: 0.04-0.06 across NR. DK: 0.055 at NR=1.0 → 0.42 at NR=5.0. τ=0.1 (V3B).** | **✅ CHARACTERIZED (v14)** |
| **NR** | **Noise ratio = max(σ_factor)/min(σ_factor)** | **scalar** | **KernelSelector threshold: 1.5. UNI-DK-01 v5.3 characterized at NR ∈ {1.0, 1.5, 2.0, 3.0, 5.0}.** | **✅ v6.0** |

---

*Mathematical Synopsis v14 | April 19, 2026*
*v14 ADDITIONS: UNI-DK-01 v5.3 characterization surface (§3.3). DK calibration finding (ECE 0.055→0.42 across NR). KernelSelector architecture settled: Option A (NR-rule) for v6.0. Conservation-law q = rolling verified accuracy (§5, §9). Auto-pause signal source changed to rolling accuracy (§9 S6). Gate UNI-DK-01 (§13).*
*v14 DEPRECATIONS: Deliverable 1 decomposition tables (cumulative-averaging methodology). "Negative learning at low NR" finding. "Cold-start dominates at high NR" narrative. Confidence-based KernelSelector (Options B/C). Confidence-based AMBER auto-pause. Confidence-based conservation-law q.*
*v12 CORRECTIONS: KernelSelector minimum 250→max(1000,20×V×α). θ_min 0.467→23.53/(α×V). Entity resolution: exact-match ✅, fuzzy ❌.*
*v12 ADDITIONS: Per-analyst η_i weighting (D5, CONDITIONAL). D6 closed (subsumed by D5). FINDING-OVR-01 (q̄ does not predict override precision). Self-calibrating gate principle.*
*v13 ADDITIONS: Re-Convergence Theorem (γ > 1 ⟺ ε_firm > 0.125). Three proof paths. 4-LLM validated (April 8, 2026).*
*v6.0 KERNEL + A=4 + REFERRAL ALL SETTLED. ~180 experiments (UNI-DK-01 added). 408 SOC backend + 525 GAE + 102 ci-platform + 46 S2P + 10 copilot-sdk (~1,057+ total).*
*A=4 confirmed: 13pp structural, kernel-independent. Tensor 6×4×6=144. Frozen scorer 90.6%.*
*DiagonalKernel validated twice: V-MV-KERNEL-HET +13.2pp peak (390 cells) + UNI-DK-01 v5.3 +7.67pp characterized at NR=5.0 (1500 cells). Curve-based citation.*
*DK calibration: ECE 0.42 at NR=5.0. Addressed architecturally at every production touchpoint.*
*Corr(noise_ratio, advantage) = 0.990 across 4 healthcare personas (HC-scaling).*
*ShrinkageKernel deprioritized to v7.0 (off-diagonal <1pp in both domains).*
*Asymmetric η (P0 fix): η_confirm=0.05, η_override=0.01. Prevents 13-27pp degradation. 24 personas + v5.3.*
*Per-analyst η_i: clip(precision_i/mean_precision, 0.5, 1.5) × η_override. D5 CONDITIONAL (0.86pp, production gate ≥1.0pp).*
*AMBER auto-pause: conservation AMBER/RED → freeze learning. Trigger = rolling verified accuracy (v14).*
*Noise ceiling kernel-dependent: L2 σ≤0.157. Diagonal σ≤0.25. Healthcare opens at v6.0.*
*KernelSelector (v6.0 settled): Option A (NR-rule > 1.5 → DK). B as v6.1 contingency. C archived.*
*Conservation-law q (v14): rolling verified accuracy over last 400 decisions. Calibration-independent.*
*ReferralRules R1-R7: policy VETO, 72.7% DR, 12% FPR. Override learning v6.5 (≥50 positives).*
*SOC A=4 / S2P A=5 — intentional asymmetry.*
*θ_min=23.53/(α×V) per-deployment. σ_max=0.034. κ*=0.20. LEARNING_ENABLED=False default.*
*Conservation law α·q·V ≥ θ_min ensures two-level compounding (three-judge validated, v14 q = rolling accuracy).*
*Re-Convergence Theorem: γ > 1 ⟺ ε_firm > 0.125. Production range 0.15-0.40. EXP-G1 measures empirically.*
*FINDING-OVR-01: override precision uncorrelated with q̄ (r=0.00 to -0.70). Measure directly.*
*"The distance metric itself compounds — Day 1: L2. Day 30: Diagonal calibrated to YOUR noise."*
*"μ is what you've learned. W is how you weight it. Rules are what you know needs human eyes."*
*"Accuracy is what the system does. Calibration is how well it knows what it does. Both matter; they are not the same thing." (v14)*

---

## Appendix A — Extended Formulations (absorbed from version addenda)

### §3 Eq. 4-final — Shrinkage-Interpolated Scoring (v6.5)

```
Eq. SHRINKAGE:
  w̃ᵢ = λ × w_DK_i + (1 - λ) × 1.0
  At λ=0: pure centroid (L2). At λ=0.5: default interpolation. At λ=1: full DK.
```

DK weights are discriminative precision weights (v15 terminology). Under Gaussian surrogate: w = 1/σ². In deployed scorer: estimated by coordinate descent for classification accuracy. The surrogate provides FORM; the estimator provides UTILITY.

### §3.2 — Fourth Proof Path (Re-Convergence)

*Path 4 — Centroid-distance (Grok primary, April 16, 2026):* Direct derivation from dist(t) = ‖μ(t) − GT‖_F. Under category-sparse disruption, Phase 2's distance-decay rate exceeds Phase 1's. D₂ = (α_disrupt/(1−α_disrupt))·‖Δ‖. θ cancels in centroid-distance space. Independent of paths (i)-(iii).

Eq. GAMMA-CENTROID: D₂ = (α_disrupt/(1−α_disrupt))·‖Δ‖ [fourth proof path metric]

Proof sources updated: GPT-4.1, Opus 4, Grok 3, Gemini 1.5 Pro (April 8); Grok 3 centroid-distance (April 16); five judges full framework (April 29).

### §5 — Conservation Law Defense-in-Depth Framing

The conservation law is one of three safety layers (see §9.1). Layer 1: shrinkage (mathematical, within scoring equation). Layer 2: promotion gate (operational, at batch boundary). Layer 3: rollback + conservation (recovery and monitoring). Conservation MONITORS degradation. Promotion gate PREVENTS bad updates. Shrinkage CONSTRAINS the interpolated scorer.

### §12 — Open Math Issues (New Items)

| Issue | What's needed | Gate | Status |
|---|---|---|---|
| Two-phase validation | Phase 1 timing + Phase 2 curve on pilot data | v6.5 commissioning | 📋 DESIGNED |
| Phase 1 quality-sensitive update | Options: confidence weighting, LLM pre-filter, consistency check, or don't solve | Phase 1 accuracy vs noise | ⚠️ OPEN (A4) |
| 2³ factorial channel composition | Cross-channel (scorer × graph × labels, 8 conditions) | Composition claim | 📋 PLANNED (A5) |
| Shrinkage non-inferiority expanded | 50+ seeds, multiple distributions | Confidence in 0/21 | 📋 PLANNED (A6) |
| Factor-version drift detection | ResetPolicy + NoveltyTracker integration | Safe FactorComputer updates | 📋 DESIGNED |

### §13 — Gate FRAMEWORK-V4

**Status:** DESIGNED. Implementation: v6.5. ~550 lines + ~200 tests.
**Prerequisites:** Framework v4 post-judge-review (5 LLMs, ~115 experiments).
**Unlocks:** CL-TWO-PHASE, CL-BATCH-PIPELINE, CL-DEFENSE-IN-DEPTH, CL-DISCRIMINATIVE-METRIC.
**Remains forbidden:** "Phase 2 is shipping" (v6.5, not v6.0). "Shrinkage guarantees safety" (defense in depth). "DK weights are inverse variances" (discriminative). "Fisher proves DK improves" (Layer A/B).

### §16 — Constraints (New Rows)

| Constraint | Why | Status |
|---|---|---|
| DK weights: discriminative precision weights | Coordinate descent for accuracy, NOT inverse variances. | ✅ TERMINOLOGY (v15) |
| Phase 1 freeze per (c,a) | Independent freeze per pair at PhasePolicy trigger. | 📋 v6.5 |
| Promotion gate required | No DK weights deploy without holdout non-inferiority. | 📋 v6.5 |
| Factor-version drift: α reduction | ResetPolicy on factor_schema_version change. | 📋 v6.5 |
| Profile state terminology | T₀/T₁ = "profile state," NOT "sufficient statistics." | ✅ TERMINOLOGY (v15) |

### §17 — Equation Index (New Rows)

| Equation | Status | Section | Description |
|---|---|---|---|
| Eq. SHRINKAGE | 📋 DESIGNED (v15) | §3 | w̃ = α × w_DK + (1-α). Shrinkage-interpolated scoring weights. |
| Eq. PHASE-1 | 📋 DESIGNED (v15) | §3.4 | Phase 1 centroid update (= Eq. 4b-final in Phase 1 context). |
| Eq. PHASE-2 | 📋 DESIGNED (v15) | §3.4 | Phase 2 batch re-estimation + shrinkage. |
| Eq. PROMOTION-GATE | 📋 DESIGNED (v15) | §3.5 | Holdout non-inferiority: accuracy_new ≥ accuracy_current - ε. |
| Eq. NOVELTY | 📋 DESIGNED (v15) | §3.6 | Nearest-neighbor: min ‖f - f'‖ over prior in (c,a). |
| Eq. GAMMA-CENTROID | ✅ 5-LLM VALIDATED | §3.2 | Fourth proof path: D₂ = (α_disrupt/(1−α_disrupt))·‖Δ‖. |

### §18 — Notation (New Symbols)

| Symbol | Meaning | Shape | Notes |
|---|---|---|---|
| T₀ | Order-0 profile state (centroid means) | (C, A, d) | Estimated by Phase 1. Transferable. |
| T₁ | Order-1 profile state (DK precision weights) | (C, A, d) | Estimated by Phase 2. Firm-specific. |
| w̃ | Shrinkage-interpolated weights | (d,) per (c,a) | α × w_DK + (1-α). |
| λ (shrinkage) | Shrinkage intensity (James-Stein mixing weight) | scalar | [0,1]. Default 0.5. Renamed from α (shrinkage) in v23 to resolve symbol collision with conservation-law α(t) = category coverage. |
| novelty | Per-decision novelty score | scalar | ‖f - f_nearest‖₂ over H(c,a). |
| W | Kernel weight matrix | (d,d) diagonal | Discriminative precision weights (v15). Under surrogate: diag(1/σ²). |

### Terminology Notes (T1-T4)

**T1:** "Sufficient statistics" → "profile state" in deployed-scorer context. Preserve in Gaussian surrogate context only.
**T2:** DK weights → "discriminative precision weights" (not "inverse variances" in deployed context). K31: coord descent 80-88% vs direct MLE 65-76%.
**T3:** Fisher → "Fisher-inspired asymmetry (Layer A/B)." Layer A = surrogate motivates. Layer B = empirical confirms (ρ ≈ +0.35 at 18/18).
**T4:** "Independent channels" → "mechanistically distinct, statistically coupled channels targeting separable error sources."

### Footer Additions (v15)

*v15: Mathematical abstractions catalog (§2.1, ten abstractions with lineage). Two-phase learning (§3.4, Phase 1 WHERE / Phase 2 WHICH DIMENSIONS). Batch pipeline (§3.5, seven steps, promotion gate). Novelty model (§3.6, four failure modes). Defense-in-depth (§9.1, three layers). Fourth γ proof path (centroid-distance, Grok). Profile state terminology. Discriminative precision weights. Fisher Layer A/B.*

*v18 (June 1, 2026): Canonical decisions D1–D4. (D1) α = cumulative category coverage = c_d/C; override-rate definition retired (it made α·q·V ∝ q(1−q), penalizing accuracy); override_rate is now a distinct symbol feeding a complacency ADVISORY only. Re-convergence quantity renamed α_cat → α_disrupt (C-MS-8) and the bare-α threshold formula disambiguated, ending the in-document α collision; α_disrupt added to the glossary. (D2) compounding vocabulary split — information-gain (b=2.11, sim-only, EXP-G1-gated) vs operational (c=1.14, bounded transient). (D3) θ_min = 23.53/(α×V) reframed as empirically-calibrated cold-start interlock (binds only below ~V=8–32 by coverage); prior derivations retired; principled derivation open. Residuals flagged for follow-up: shrinkage coefficient renamed from α to λ (completed in v23); "20×V×α" usages (§15/§16) need their α defined; the code variable `alpha` in the re-convergence formula should be renamed α_disrupt in the Option C pass. Edits: C-MS-1…C-MS-8.*
*Authority: framework v4 (post-judge-review, April 29, 2026). Claims v6.*

---

---

## Appendix B — Phase 7 Results (August 2026)

### RL-Scorer Line: Definitively Closed

Four experiments across six RL-derived allocation strategies tested whether RL reward signals, routed into the scorer's learning rate (η), improve convergence over uniform η=0.05:

| Experiment | Signal | Strategies | Result |
|---|---|---|---|
| EXP-RL-DIRECT-1 | First-order (accuracy gap) | 3 α variants | Negative (1/3 faster, worse AUT_ACC) |
| EXP-RL-DIRECT-3 | σ-directed enrichment | 5 arms | Negative (uniform +6.9pp > σ-directed +4.3pp) |
| EXP-RL-DIRECT-4 | Second-order (rate) | Pre-flight | Apparatus-limited (SNR 0.37-0.60) |
| EXP-RL-SCORER | EMA-rate, Thompson, hybrid | 3 strategies | Definitively negative (best Δ=0.4%, within noise) |

**Conclusion:** Uniform η=0.05 is robust for centroid learning. The sidecar (AgentEvolver variant evolution) is the right RL architecture — RL belongs in operational-context evolution, not in scorer η allocation.

**CLAIM-CTRL-2C — RL controls the enrichment budget (a policy over `route`), deployably and safely.**
A learned budget controller over the enrichment loop delivers +6.82 pts (S2P) / +6.47 pts (SOC) at fewer
reads (1.43 / 1.75 vs fixed 2.0), 0% clean-pause, 100% sustained-poison detection. A Lagrangian sweep over
the constraint penalty finds the best point at λ=0 — safety comes from the substrate (persistent state,
per-domain floors, real poison protocol), not a tuned penalty (safe-by-construction).
- **Classification:** the enrichment controller is **architecture** (a policy over `route`'s budget), not an
  engine operation; its offline RL training is a calibration procedure that produces the policy parameter.
  Logged here because it is an RL result the ledger tracks alongside the in-scorer negative.
- **Signal tier:** T-geom + T-sim. **Maturity tier:** Tier 2 — two copilots (S2P, SOC), in-distribution;
  does not port; live magnitude → T-pilot.
- **Relation to the existing RL negative:** the in-scorer directed-η result stands as "uniform is robust"
  (RL out of the decision); CTRL-2C is RL *in a different loop* (the enrichment budget) — no conflict, they
  are different loops. RL never selects the action (I1 / F-25).

**Measured: logistic baseline curvature.** The learning curve is logistic (R²≈0.88), with d²q/dt² > 0 for t < ~330 decisions (inflection ~327-361). Early positive curvature is the natural shape of centroid convergence — not an RL effect.

### Self-Computation Formalism

**Formalism.** (G, Φ, C): G=centroid geometry (Level 0), Φ=structural configuration (factor space, sources, processes), C=conservation. Level 0 reshapes G within fixed Φ; Level 1 reshapes Φ itself via shadow-test → conservation-gated promotion.

**Convergence:** Each promoted structural change is non-degrading (gate requires improvement); Φ-space is finite (bounded by enterprise systems); q is bounded above → converges to local optimum Φ* in finitely many steps.

**Calibration protocol (validated, EXP-SELF-COMPUTE v2):** New factors observe/learn without entering scoring (Phase 2a), then integrate after convergence (Phase 2b). Distances declined 3/3 seeds; cold-start J-curve eliminated.

**Conservation precondition (characterized, EXP-SELF-COMPUTE v3):** Level 1 requires current config above θ_min. Below it, conservation deadlocks calibration (zero convergence). Realistic in production (initial configs PILOT_GATED).

**Two pathways:** (a) data-platform evolution (DataOps + AgentEvolver); (b) process evolution (tech-process fusion under conservation gate).

### SA Reasoning Autonomy + AE Decision Autonomy

**SituationAnalyzer (reasoning autonomy).** Uses context graphs to consolidate semantic meaning — context-dependent factor vectors vs heuristic dispatch. Evidence: V-CGA-FROZEN (+5.9pp from enrichment = graph-mediated noise reduction, MEASURED, p=1e-6). Noise redistribution test (SA-REASONING) established an apparatus boundary — L2 dominated by noisiest dims; SA value is noise REDUCTION through graph-derived signal (validated at +5.9pp), not noise redistribution.

**Per-decision abstention (safety primitive).** Abstain when min_a ‖f−μ‖ > r_max(c). EXP-SA-ABSTAIN: 100% OOD detection, 4.4-5.1% FP, reduced AMBER episodes. Does NOT improve accuracy — safety gate complementing conservation.

**AgentEvolver (decision autonomy, VALIDATED).** Under 20% adversarial poisoning through the full learning loop, AE's drift-triggered rollback + per-category η damping:

| Metric | Frozen (no AE) | AE | Δ |
|---|---|---|---|
| Non-recovery | 56.9% | 14.4% | −42.5pp |
| Centroid drift | 0.307 | 0.124 | −60% |
| Recovery time | 1-9 decisions | 1 decision | Consistent |

AE triggered 4-6 rollback+damping actions per seed within ~50-100 decisions of adversarial onset, all within conservation bounds.

**AE-GATE finding.** n_min=10: 59% power, 44% FPR. Strict-inequality gate structurally capped at 50% power when true effect = threshold. Production recommendation: replace with statistical test (z-test, p<0.05, Δ̂>3pp).

### Judgment Memory — Fourth Cognitive-Architecture Type

| Memory type | Stores | Answers | Built from | Graph op |
|---|---|---|---|---|
| Episodic | What happened | "Seen before?" | Events | Read |
| Semantic | What is true | "Know about X?" | Facts | Read |
| Procedural | How to act | "Do here?" | Rules | Route |
| **Judgment** | **Decision quality + noise** | **"How reliably does A work in S?"** | **Outcome-conditioned variance** | **Reshape** |

Read/Route extend existing memory types with better graph structure. Reshape adds a type the others cannot produce — the one that compounds.

**JM apparatus quantification (v26).** The JM redesign harness (40 deployments, 5,000
bootstrap resamples) provides the first measured evidence that judgment memory compounds:
cumulative advantage c = 1.387, CI [1.308, 1.477]; +21.96pp bounded accuracy gain over a
frozen twin. Full exponent family and claims gate: §10.2, Gate JM-APPARATUS (§13).

**σ survives DK — as diagnostic, not operational.** Three applications tested, two negative:

| Application | Result | Status |
|---|---|---|
| Scoring weight (DK: W=diag(1/σ²)) | Did not survive de-circularization | Characterized negative |
| Enrichment-direction signal (η ∝ σ) | Uniform outperforms (+6.9 vs +4.3pp) | Characterized negative |
| Diagnostic (signal-confidence inversion) | Surfaces practitioner-confidence bias | Survives |

### Phase 7 Experiment Record

| # | ID | Question | Result | Key Number |
|---|---|---|---|---|
| 48 | EXP-RL-DIRECT | Category-directed η (first-order) | ROBUSTNESS CONFIRMED | Uniform η robust across all seeds (R²=0.879). α=0.5 reaches competence 23 decisions earlier (cold-start option) |
| 49 | EXP-RL-DIRECT (curvature) | Learning curve shape | MEASURED | Logistic R²≈0.88, inflection ~330 |
| 50 | EXP-RL-DIRECT-3 | σ-directed enrichment | ENRICHMENT VALIDATED | Enrichment +6.9pp (uniform), +4.3pp (σ-directed). Uniform is robust default. σ-direction has consistent positive signal |
| 51 | EXP-SELF-COMPUTE v1 | Uncalibrated transition | APPARATUS | Cold-start trough |
| 52 | EXP-SELF-COMPUTE v2 | Calibrated transition | CALIBRATION VALIDATED | 3/3 seeds |
| 53 | EXP-SELF-COMPUTE v3 | Strong structural contrast | PRECONDITION | Conservation deadlock |
| 54 | EXP-RL-DIRECT-4 | Rate signal pre-flight | APPARATUS-LIMITED | SNR 0.37-0.60 |
| 55 | EXP-RL-SCORER | RL-in-scorer (3 strategies) | ARCHITECTURE CONFIRMED | Centroid geometry converges efficiently under uniform η. Sidecar architecture validated — RL belongs in AgentEvolver, not scorer |
| 56 | EXP-SA-ABSTAIN | Per-decision abstention | SAFETY VALIDATED | 100% detection, <5% FP |
| 57 | EXP-AE-GATE | Promotion gate power | DESIGN FINDING | 59% power, 44% FPR at n=10 |
| 58 | EXP-SA-REASONING | Graph-correlated noise | APPARATUS BOUNDARY | L2 dominated by noisiest dims. SA validated through V-CGA-FROZEN (+5.9pp), not noise redistribution |
| 59 | EXP-AE-DECISION | Runtime evolution, adversarial | **VALIDATED** | Non-recovery 57%→14% |

### Experimental Philosophy (v20)

**Experiments lead the code, not the reverse.** A theorem-vs-code mismatch is a discovery → roadmap item. Self-computation, per-decision abstention, and AE adversarial protection were validated experimentally before the production code implements them.

**Architectural value drives claims; experiments provide grounding.** The DK investigation illustrates this: the architectural thesis (the graph's decision geometry reshapes from verified outcomes) survived the preprocessing-dependence finding unchanged — only the kernel recommendation was refined (from DK-as-default to L2-as-default with DK as a validated-per-deployment option). Negatives were as valuable as positives: each sharpened what the architecture IS by establishing what it ISN'T.

### Standing Rules — Phase 7 Additions

- **RL-in-scorer CLOSED.** Four experiments, 6+ strategies: none beat uniform η=0.05. RL belongs in the sidecar.
- **Logistic curvature MEASURED.** d²q/dt² > 0 for t < ~330 (baseline centroid convergence).
- **SA reasoning autonomy:** V-CGA-FROZEN +5.9pp = graph-mediated noise reduction. SA validated through enrichment (+5.9pp), not noise redistribution.
- **AE decision autonomy VALIDATED:** 57%→14% non-recovery (−42.5pp). Complements conservation.
- **Self-computation precondition:** Level 1 requires config above θ_min. Below → deadlock.
- **AE-GATE:** n_min=10 underpowered. Recommend statistical test.

---

*math_synopsis v26 | September 20, 2026 | v25 + JM redesign results propagated from jm_redesign_results_note_v6 — cumulative advantage c = 1.387 (C1), discovery α_d = 2.150 (C2), per-threat-model conservation (C3), +21.96pp accuracy reframe (C4). Exponent family table (§10.2). Gate JM-APPARATUS (§13). A1 reconciliation. γ/c exponent disambiguation. Landmine rule codified. Prior: v20 consolidated v18 + Phase 7.*
*Total experiments: ~194 (59 primary + factorial sub-cells) across 7 phases + JM apparatus (40 deployments, 5,000 bootstrap resamples)*
*Companion documents: cga_arxiv_short v15, jm_redesign_results_note v6, graph_native_reasoning_hero v23 (practitioner blog), innovation_note v28, ci_blog v18*
